
<?php $__env->startSection('admin_content'); ?>


<div class="container">
    <div class="col-lg-11">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>
                            Delivery
                        </h6>
                    </div>
                    <div class="col-lg-6 col-5 my-auto text-end">
                        <div class="dropdown float-lg-end pe-4">
                            <a class="cursor-pointer" id="dropdownTable" ata-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-secondary"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <form>
                <?php echo csrf_field(); ?>
                <div class="card-body px-0 pb-2">
                    <div class="col-md-7 container">
                        <div class="input-group input-group-outline mb-3">
                            <select name="city" id="city" class="form-control choose city">
                                <option value="">
                                    -----Choose your city-----
                                </option>
                                <?php if(!$city->isEmpty()): ?>
                                <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ci->matp); ?>">
                                        <?php echo e($ci->name_city); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <option disabled>Something went wrong</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <select name="province" id="province" class="form-control province choose">
                                <option value="">
                                    -----Choose your province-----
                                </option>
                            </select>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <select name="wards" id="wards" class="form-control wards">
                                <option value="">
                                    -----Choose your wards-----
                                </option>
                            </select>
                        </div>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">
                                Delivery fee
                            </label>
                            <input type="text" name="fee_ship" id="wards" id="freeShip" class="form-control fee_ship">
                        </div>
                        <?php $__errorArgs = ['fee_ship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="text-center">
                    <button type="button" name="add_delivery" class="btn btn-info add_delivery">
                        Add delivery
                    </button>
                </div>
            </form>
            <hr class="my-4">
            <div id="load_delivery">

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/delivery/add_delivery.blade.php ENDPATH**/ ?>