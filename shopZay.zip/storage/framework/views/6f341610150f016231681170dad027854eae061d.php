<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('public/backend/images/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('public/backend/images/favicon.png')); ?>">
    <title>
        Admin | Dashboard
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <!-- Nucleo Icons -->
    <link href="<?php echo e(asset('public/backend/css/nucleo-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/backend/css/nucleo-svg.css')); ?>" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <!-- CSS Files -->
    <link id="pagestyle" href="<?php echo e(asset('public/backend/css/material-dashboard.css?v=3.0.2')); ?>" rel="stylesheet" />
</head>

<body class="g-sidenav-show  bg-gray-200">
    <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0" href="/admin2" target="_blank">
                <img src="<?php echo e(asset('public/backend/images/logo-ct.png')); ?>" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-1 font-weight-bold text-white">Hello
                    <?php

                    $name = Session::get('admin_name');

                    if ($name) {
                        echo  $name;
                    }
                    ?>
                </span>
            </a>
        </div>
        <hr class="horizontal light mt-0 mb-2">
        <div class="collapse navbar-collapse  w-auto  max-height-vh-100" id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('dashboard') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/dashboard')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">dashboard</i>
                        </div>
                        <span class="nav-link-text ms-1">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('category') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/show-category')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">table_view</i>
                        </div>
                        <span class="nav-link-text ms-1">Category</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('subcategory') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/show-sub-category')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">receipt_long</i>
                        </div>
                        <span class="nav-link-text ms-1">SubCategory</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('product') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/show-product')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">view_in_ar</i>
                        </div>
                        <span class="nav-link-text ms-1">Product</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('coupon') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/show-coupon')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                        </div>
                        <span class="nav-link-text ms-1">Coupon</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('delivery') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/delivery')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">local_shipping</i>
                        </div>
                        <span class="nav-link-text ms-1">Delivery</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('order') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/order')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">list_alt</i>
                        </div>
                        <span class="nav-link-text ms-1">Order</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteNamed('slider') ? 'bg-gradient-primary' : ''); ?>" href="<?php echo e(URL::to('/slider')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">slideshow</i>
                        </div>
                        <span class="nav-link-text ms-1">Slider</span>
                    </a>
                </li>
                <li class="nav-item mt-3">
                    <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white " href="./pages/profile.html">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">person</i>
                        </div>
                        <span class="nav-link-text ms-1">Profile</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white " href="<?php echo e(URL::to('/logout')); ?>">
                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">login</i>
                        </div>
                        <span class="nav-link-text ms-1">Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>
    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <!-- Navbar -->
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
            <div class="container-fluid py-1 px-3">
                <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
                    <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                        <div class="input-group input-group-outline">
                            <label class="form-label">Type here...</label>
                            <input type="text" class="form-control">
                        </div>
                    </div>
                    <ul class="navbar-nav  justify-content-end">
                        <li class="nav-item d-flex align-items-center">
                            <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                                <i class="fa fa-user me-sm-1"></i>
                                <span class="d-sm-inline d-none">
                                    <?php
                                    if ($name) {
                                        echo  $name;
                                    }
                                    ?>
                                </span>
                            </a>
                        </li>
                        <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
                            <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                                <div class="sidenav-toggler-inner">
                                    <i class="sidenav-toggler-line"></i>
                                    <i class="sidenav-toggler-line"></i>
                                    <i class="sidenav-toggler-line"></i>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item px-3 d-flex align-items-center">
                            <a href="javascript:;" class="nav-link text-body p-0">
                                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <?php echo $__env->yieldContent('admin_content'); ?>
    </main>
    <div class="fixed-plugin">
        <a class="fixed-plugin-button text-dark position-fixed px-3 py-2">
            <i class="material-icons py-2">settings</i>
        </a>
        <div class="card shadow-lg">
            <div class="card-header pb-0 pt-3">
                <div class="float-start">
                    <h5 class="mt-3 mb-0">Material UI Configurator</h5>
                    <p>See our dashboard options.</p>
                </div>
                <div class="float-end mt-4">
                    <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
                        <i class="material-icons">clear</i>
                    </button>
                </div>
                <!-- End Toggle Button -->
            </div>
            <hr class="horizontal dark my-1">
            <div class="card-body pt-sm-3 pt-0">
                <!-- Sidebar Backgrounds -->
                <div>
                    <h6 class="mb-0">Sidebar Colors</h6>
                </div>
                <a href="javascript:void(0)" class="switch-trigger background-color">
                    <div class="badge-colors my-2 text-start">
                        <span class="badge filter bg-gradient-primary active" data-color="primary" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
                        <span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
                    </div>
                </a>
                <!-- Sidenav Type -->
                <div class="mt-3">
                    <h6 class="mb-0">Sidenav Type</h6>
                    <p class="text-sm">Choose between 2 different sidenav types.</p>
                </div>
                <div class="d-flex">
                    <button class="btn bg-gradient-dark px-3 mb-2 active" data-class="bg-gradient-dark" onclick="sidebarType(this)">Dark</button>
                    <button class="btn bg-gradient-dark px-3 mb-2 ms-2" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
                    <button class="btn bg-gradient-dark px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
                </div>
                <p class="text-sm d-xl-none d-block mt-2">You can change the sidenav type just on desktop view.</p>
                <!-- Navbar Fixed -->
                <div class="mt-3 d-flex">
                    <h6 class="mb-0">Navbar Fixed</h6>
                    <div class="form-check form-switch ps-0 ms-auto my-auto">
                        <input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
                    </div>
                </div>
                <hr class="horizontal dark my-3">
                <div class="mt-2 d-flex">
                    <h6 class="mb-0">Light / Dark</h6>
                    <div class="form-check form-switch ps-0 ms-auto my-auto">
                        <input class="form-check-input mt-1 ms-auto" type="checkbox" id="dark-version" onclick="darkMode(this)">
                    </div>
                </div>
                <hr class="horizontal dark my-sm-4">
            </div>
        </div>
    </div>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('public/backend/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/js/plugins/chartjs.min.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/34.1.0/classic/ckeditor.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function preview() {
            frame.src = URL.createObjectURL(event.target.files[0]);
            var file = document.getElementById('productImage')
            var bodyFormData = new FormData();
            bodyFormData.append('product_image', file.files[0]);

        }
    </script>
    <script>
        $(document).ready(function() {
            fetch_delivery();

            function fetch_delivery() {
                var _token = $('input[name="_token"]').val();
                $.ajax({
                    url: '<?php echo e(url("/select-feeship")); ?>',
                    method: 'POST',
                    data: {
                        _token: _token
                    },
                    success: function(data) {
                        $('#load_delivery').html(data);
                    }
                });
            }
            $(document).on('blur', '.fee_feeship_edit', function() {
                var feeship_id = $(this).data('feeship_id');
                var fee_value = $(this).text();
                var _token = $('input[name="_token"]').val();
                // alert(feeship_id);
                // alert(fee_value);
                $.ajax({
                    url: '<?php echo e(url("/update-delivery")); ?>',
                    method: 'POST',
                    data: {
                        feeship_id: feeship_id,
                        fee_value: fee_value,
                        _token: _token
                    },
                    success: function(data) {
                        fetch_delivery();
                    }
                });
            });
            $('.add_delivery').click(function() {
                var city = $('.city').val();
                var province = $('.province').val();
                var wards = $('.wards').val();
                var _token = $('input[name="_token"]').val();
                var fee_ship = $('.fee_ship').val();
                if (city == '' || province == '' || wards == '' || fee_ship == '') {
                    Swal.fire({
                        icon: 'warning',
                        title: 'You must fill all field',
                        showConfirmButton: false,
                        timer: 1800
                    })
                } else {
                    if (fee_ship > 0) {
                        $.ajax({
                            url: '<?php echo e(url("/insert-delivery")); ?>',
                            method: 'POST',
                            data: {
                                city: city,
                                province: province,
                                _token: _token,
                                wards: wards,
                                fee_ship: fee_ship
                            },
                            success: function(data) {
                                fetch_delivery();
                            },
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Delivery fee must > 0'
                        })
                    }
                }
            });
            $('.choose').change(function() {
                var action = $(this).attr('id');
                var ma_id = $(this).val();
                var _token = $('input[name="_token"]').val();
                var result = '';
                // alert(action);
                // alert(matp);
                // alert(_token);
                if (action == 'city') {
                    result = 'province';
                } else {
                    result = 'wards';
                }
                $.ajax({
                    url: '<?php echo e(url("/select-delivery")); ?>',
                    method: 'POST',
                    data: {
                        action: action,
                        ma_id: ma_id,
                        _token: _token
                    },
                    success: function(data) {
                        $('#' + result).html(data);
                    }
                });
            });
        })
    </script>
    <script>
        $(document).ready(function() {
            $('.choose').change(function() {
                var action = $(this).attr('id');
                var cate_id = $(this).val();
                var _token = $('input[name="_token"]').val();
                var result = '';
                if (action == 'category') {
                    result = 'subcategory';
                }
                $.ajax({
                    url: '<?php echo e(url("/select-category")); ?>',
                    method: 'POST',
                    data: {
                        action: action,
                        cate_id: cate_id,
                        _token: _token
                    },
                    success: function(data) {
                        $('#' + result).html(data);
                    }
                });
            });
        })
    </script>
    <script type="text/javascript">
        ClassicEditor
            .create(document.querySelector('#ckeditorAdd'))
            .catch(error => {
                console.error(error);
            });

        ClassicEditor
            .create(document.querySelector('#ckeditorAdd1'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('public/backend/js/material-dashboard.min.js?v=3.0.2')); ?>"></script>
    <script>
        $(document).ready(function() {
            window.setTimeout(function() {
                $("#alertMessage").fadeOut(1000)
            }, 2000);
        });
    </script>
    <script>
        $('.order_details').change(function() {
            var order_status = $(this).val();
            var order_id = $(this).children(":selected").attr("id");
            var _token = $("input[name='_token']").val();

            // lay so luong
            quantity = [];
            $("input[name='product_sales_quantity']").each(function() {
                quantity.push($(this).val());
            });
            //lay id
            order_product_id = [];
            $("input[name='order_product_id']").each(function() {
                order_product_id.push($(this).val());
            });
            j = 0;
            if (order_status == 2) {
                for (i = 0; i < order_product_id.length; i++) {
                    //So luong order
                    var order_qty = $('.order_qty_' + order_product_id[i]).val();
                    //So luong trong kho
                    var order_qty_storage = $('.order_qty_storage_' + order_product_id[i]).val();
                    if (parseInt(order_qty) > parseInt(order_qty_storage)) {
                        j = j + 1;
                        if (j == 1) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Product in stock not enough',
                                showConfirmButton: false,
                                timer: 1800
                            })
                        }
                        $('.color_qty_' + order_product_id[i]).css('background', '#C11B17');
                    }
                }
                if (j == 0) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Delivering this order',
                        showConfirmButton: false,
                        timer: 1800
                    })
                }
            } else if (order_status == 3) {
                Swal.fire({
                    icon: 'success',
                    title: 'This order has been canceled',
                    showConfirmButton: false,
                    timer: 1800
                })
            } else {
                Swal.fire({
                    icon: 'success',
                    title: 'Not handle yet',
                    showConfirmButton: false,
                    timer: 1800
                })
            }
            if (j == 0) {
                $.ajax({
                    url: "<?php echo e(url('/update-order-qty')); ?>",
                    method: 'POST',
                    data: {
                        _token: _token,
                        order_status: order_status,
                        order_id: order_id,
                        quantity: quantity,
                        order_product_id: order_product_id
                    },
                    success: function(data) {
                        setTimeout(function() { // wait for 5 secs(2)
                            location.reload(); // then reload the page.(3)
                        }, 2000);
                    }
                });

            }

        });
    </script>
    <script>
        $('.update_quantity_order').click(function() {
            var order_product_id = $(this).data('product_id');
            var order_qty = $('.order_qty_' + order_product_id).val();
            var order_code = $('.order_code').val();
            var _token = $('input[name=_token]').val();
            $.ajax({
                url: "<?php echo e(url('/update-qty')); ?>",
                method: 'POST',
                data: {
                    _token: _token,
                    order_qty: order_qty,
                    order_code: order_code,
                    order_product_id: order_product_id
                },
                success: function(data) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Update product quantity',
                        showConfirmButton: false,
                        timer: 1800
                    })
                    setTimeout(function() { // wait for 5 secs(2)
                        location.reload(); // then reload the page.(3)
                    }, 2000);
                }
            });
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin_layout.blade.php ENDPATH**/ ?>