
<?php $__env->startSection('admin_content'); ?>


<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <h6 class="text-white text-capitalize ps-3">
                            <?php echo e(__('admin/product.Product table')); ?>

                        </h6>
                    </div>
                </div>
                <div class="col-11 text-end">
                    <a href="<?php echo e(URL::to('/add-product')); ?>" class="btn bg-gradient-dark mb-0">
                        <i class="material-icons text-sm">
                            add
                        </i>&nbsp;&nbsp;
                        <?php echo e(__('admin/product.Add Product')); ?>

                    </a>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="table-responsive p-0">
                        <div class="container mt-3">
                            <div class="d-flex justify-content-between">
                                <div class="input-group input-group-outline m-3">
                                    <label class="form-label">
                                        <?php echo e(__('admin/product.Search your product name')); ?>

                                    </label>
                                    <input type="text" id="myFilter" onkeyup="myFilter()" class="form-control">
                                </div>
                                <form class="input-group input-group-outline m-3">
                                    <?php echo csrf_field(); ?>
                                    <select name="product_sort" id="product_sort" class="form-control">
                                        <option value="<?php echo e(Request::url()); ?>?sort_by=none"><?php echo e(__('admin/product.Sort PRODUCT PRICE by')); ?></option>
                                        <option value="<?php echo e(Request::url()); ?>?sort_by=asc" <?php echo e(Request::fullurl() == Request::url().'?sort_by=asc' ? "selected" : ""); ?>><?php echo e(__('admin/product.Ascending')); ?></option>
                                        <option value="<?php echo e(Request::url()); ?>?sort_by=desc" <?php echo e(Request::fullurl() == Request::url().'?sort_by=desc' ? "selected" : ""); ?>><?php echo e(__('admin/product.Descending')); ?></option>
                                    </select>
                                </form>
                                <form class="input-group input-group-outline m-3">
                                    <?php echo csrf_field(); ?>
                                    <select name="product_filter_category" id="product_filter_category" class="form-control">
                                        <option value="<?php echo e(Request::url()); ?>?filter_category_with=none"><?php echo e(__('admin/product.Filter CATEGORY by')); ?></option>
                                        <?php if(!$get_category->isEmpty()): ?>
                                        <?php $__currentLoopData = $get_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(Request::url()); ?>?filter_category_with=<?php echo e($cate->category_id); ?>" 
                                                        <?php echo e(Request::fullurl() == Request::url().'?filter_category_with='.$cate->category_id ? "selected" : ""); ?>><?php echo e($cate->category_name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <option disabled><?php echo e(__('admin/product.No category available')); ?></option>
                                        <?php endif; ?>
                                    </select>
                                </form>
                                <form class="input-group input-group-outline m-3">
                                    <?php echo csrf_field(); ?>
                                    <select name="product_filter_subcategory" id="product_filter_subcategory" class="form-control">
                                        <option value="<?php echo e(Request::url()); ?>?filter_subcategory_with=none"><?php echo e(__('admin/product.Filter SUBCATEGORY by')); ?></option>
                                        <?php if(!$get_subcategory->isEmpty()): ?>
                                        <?php $__currentLoopData = $get_subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(Request::url()); ?>?filter_subcategory_with=<?php echo e($subcate->subcategory_id); ?>" 
                                                        <?php echo e(Request::fullurl() == Request::url().'?filter_subcategory_with='.$subcate->subcategory_id ? "selected" : ""); ?>><?php echo e($subcate->subcategory_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <option disabled><?php echo e(__('admin/product.No subcategory available')); ?></option>
                                        <?php endif; ?>
                                    </select>
                                </form>
                                <form class="input-group input-group-outline m-3">
                                    <?php echo csrf_field(); ?>
                                    <select name="product_filter_status" id="product_filter_status" class="form-control">
                                        <option value="<?php echo e(Request::url()); ?>?filter_status_with=none"><?php echo e(__('admin/product.Filter PRODUCT STATUS by')); ?></option>
                                        <option value="<?php echo e(Request::url()); ?>?filter_status_with=1" <?php echo e(Request::fullurl() == Request::url().'?filter_status_with=1' ? "selected" : ""); ?>><?php echo e(__('admin/product.Show')); ?></option>
                                        <option value="<?php echo e(Request::url()); ?>?filter_status_with=0" <?php echo e(Request::fullurl() == Request::url().'?filter_status_with=0' ? "selected" : ""); ?>><?php echo e(__('admin/product.Hide')); ?></option>
                                    </select>
                                </form>
                            </div>
                        </div>
                        <table class="table align-items-center mb-0" id="filterTable">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">
                                        <?php echo e(__('admin/product.ID')); ?>

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        <?php echo e(__('admin/product.Product Name')); ?>

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">
                                        <?php echo e(__('admin/product.Product Quantity')); ?>

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">
                                        <?php echo e(__('admin/product.Product Price')); ?>

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        <?php echo e(__('admin/product.Product Image')); ?>

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        <?php echo e(__('admin/product.Category')); ?>

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        <?php echo e(__('admin/product.Subcategory')); ?>

                                    </th>
                                    <th class="text-center text-uppercase text-secondary font-weight-bolder opacity-7">
                                        <?php echo e(__('admin/product.Show/Hide')); ?>

                                    </th>
                                    <th class="text-secondary opacity-7"></th>
                                    <th class="text-secondary opacity-7"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!$show_product->isEmpty()): ?>
                                <?php $__currentLoopData = $show_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex px-2 py-1">
                                            <div class="justify-content-center">
                                                <?php echo e($pro->product_id); ?>

                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($pro->product_name); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($pro->product_quantity); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($pro->product_price); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <img src="<?php echo e(asset('storage/app/public/products/'.$pro->product_image)); ?>" height="130" width="130" alt="No image available">
                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($pro->category_name); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($pro->subcategory_name); ?>

                                        </p>
                                    </td>

                                    <td class="align-middle text-center">
                                        <?php
                                        if ($pro->product_status == 1) {
                                        ?>
                                            <a href="<?php echo e(URL::to('/unactive-product/'.$pro->product_id)); ?>">
                                                <i class="material-icons" style="font-size: 40px; color:green;">
                                                    thumb_up
                                                </i>
                                            </a>
                                        <?php
                                        } else {
                                        ?>
                                            <a href="<?php echo e(URL::to('/active-product/'.$pro->product_id)); ?>">
                                                <i class="material-icons" style="font-size: 40px; color:red;">
                                                    thumb_down
                                                </i>
                                            </a>
                                        <?php
                                        }
                                        ?>
                                    </td>
                                    <td class="align-middle">
                                        <a href="<?php echo e(URL::to('/edit-product/'.$pro->product_id)); ?>" class="font-weight-bold" data-toggle="tooltip">
                                            <i class="material-icons" style="font-size: 30px;">
                                                edit
                                            </i>
                                        </a>
                                    </td>
                                    <td class="align-middle">
                                        <a onclick="return confirm('Are you sure to delete?')" href="<?php echo e(URL::to('/delete-product/'.$pro->product_id)); ?>" class="font-weight-bold" data-toggle="tooltip">
                                            <i class="material-icons" style="font-size: 30px;">
                                                delete
                                            </i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <td colspan="8"> 
                                    <center>
                                        <h3>
                                            <?php echo e(__('admin/product.Nothing here')); ?>

                                        </h3>
                                    </center>
                                </td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo $show_product->render('components.admin_paginate.admin_pagination'); ?>


        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/product/show_product.blade.php ENDPATH**/ ?>