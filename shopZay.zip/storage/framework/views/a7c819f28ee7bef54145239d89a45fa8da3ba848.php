<?php $__env->startSection('category_content'); ?>

<div class="col-lg-3">
    <h1 class="h2 pb-4">Categories</h1>
    <ul class="list-unstyled templatemo-accordion">
        <li class="pb-3">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="collapsed d-flex justify-content-between h3 text-decoration-none" href="<?php echo e(URL::to('/category/'.$cate->category_id)); ?>">
                <?php echo e($cate->category_name); ?>

                <i class="fa fa-fw fa-chevron-circle-down mt-1"></i>
            </a>
            <ul class="collapse show list-unstyled pl-3">
                <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cate->category_id == $sub->category_id): ?>
                <li><a class="text-decoration-none" href="<?php echo e(URL::to('/subcategory/'.$sub->subcategory_id)); ?>"><?php echo e($sub->subcategory_name); ?></a></li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </li>
    </ul>
</div>

<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/components/categoryBar/category.blade.php ENDPATH**/ ?>