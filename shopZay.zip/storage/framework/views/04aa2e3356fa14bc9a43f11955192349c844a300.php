
<?php $__env->startSection('content'); ?>


<?php

$content = Cart::content();

$tax = Cart::pricetotal(0, ',', '') * 10 / 100;

$total_all = Cart::total(0, ',', '') + Session::get('fee');

$orderDate = Carbon\Carbon::now();

$total_usd = 0;

?>
<div class="modal fade" id="OrderBill" data-bs-backdrop="static" 
    data-bs-keyboard="false" tabindex="-1" 
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <button id="closeBill" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="text-left logo p-2 px-5">

                                <a class="navbar-brand text-success logo h1 align-self-center" 
                                    href="<?php echo e(URL::to('/')); ?>">
                                    <?php echo e(__('checkout/checkout.Zay Shop')); ?>

                                </a>


                            </div>
                            <center>
                                <img src="https://media2.giphy.com/media/a0h7sAqON67nO/giphy.gif" alt="">
                            </center>
                            <h3 class="text-left logo p-2 px-5" id="countdown"></h3>
                            <div class="invoice p-5">

                                <h5>
                                    <?php echo e(__('checkout/checkout.Your order is now Confirmed!')); ?>

                                </h5>

                                <span class="font-weight-bold d-block mt-4">
                                    Hello, 
                                    <?php 
                                        echo Session::get('account_name'); 
                                    ?>
                                </span>
                                <span>
                                    <?php echo e(__('checkout/checkout.You order has been confirmed and will coming to you as soon as possible!')); ?>

                                </span>

                                <div class="payment border-top mt-3 mb-3 border-bottom table-responsive">

                                    <table class="table table-borderless">

                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="py-2">

                                                        <span class="d-block text-muted">
                                                            <?php echo e(__('checkout/checkout.Order Date')); ?>

                                                        </span>
                                                        <span> 
                                                            <?php 
                                                                echo $orderDate->format('d/m/Y') 
                                                            ?>
                                                        </span>

                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="py-2">

                                                        <span class="d-block text-muted">
                                                            <?php echo e(__('checkout/checkout.Payment')); ?>

                                                        </span>
                                                        <span id="shipping_method"></span>

                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="py-2">

                                                        <span class="d-block text-muted">
                                                            <?php echo e(__('checkout/checkout.Shipping')); ?>

                                                        </span>
                                                        <?php if(Session::get('city')): ?>
                                                        <span>
                                                            <?php 
                                                                echo Session::get('city'); 
                                                            ?>
                                                        </span>
                                                        <?php else: ?>
                                                        <span id="shipping_city"></span>
                                                        <?php endif; ?>
                                                    </br>
                                                        <?php if(Session::get('province')): ?>
                                                        <span>
                                                            <?php 
                                                                echo Session::get('province');
                                                            ?>
                                                        </span>
                                                        <?php else: ?>
                                                        <span id="shipping_province"></span>
                                                        <?php endif; ?>
                                                    </br>
                                                        <?php if(Session::get('ward')): ?>
                                                        <span>
                                                            <?php 
                                                                echo Session::get('ward'); 
                                                            ?>
                                                        </span>
                                                        <?php else: ?>
                                                        <span id="shipping_ward"></span>
                                                        <?php endif; ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="py-2">

                                                        <span class="d-block text-muted">
                                                            <?php echo e(__('checkout/checkout.Address')); ?>

                                                        </span>
                                                        <span id="shipping_address"></span>

                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>





                                </div>




                                <div class="product border-bottom table-responsive">

                                    <table class="table table-borderless">

                                        <tbody>
                                            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td width="20%">

                                                    <img src="<?php echo e(URL::to('/storage/app/public/products/'.$con->options->image)); ?>" 
                                                        width="90px">

                                                </td>

                                                <td width="60%">
                                                    <span class="font-weight-bold">
                                                        <?php echo e($con->name); ?>

                                                    </span>
                                                    <div class="product-qty">
                                                        <small class="text-muted">
                                                            <?php echo e(__('checkout/checkout.Quantity:')); ?><?php echo e($con->qty); ?>

                                                        </small>

                                                    </div>
                                                </td>
                                                <td width="20%">
                                                    <div class="text-right">
                                                        <span class="font-weight-bold">
                                                            <?php echo e($con->price(0 , ',' , '.').' '.'đ'); ?>

                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>



                                </div>



                                <div class="row d-flex justify-content-end">

                                    <div class="col-md-5">

                                        <table class="table table-borderless">

                                            <tbody class="totals">

                                                <tr>
                                                    <td>
                                                        <div class="text-left">

                                                            <span class="text-muted">
                                                                <?php echo e(__('checkout/checkout.Subtotal')); ?>

                                                            </span>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-right">
                                                            <span>
                                                                <?php echo e(Cart::pricetotal(0 , ',' , '.').' '.'đ'); ?>

                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <?php if(Session::get('fee')): ?>
                                                <tr>
                                                    <td>
                                                        <div class="text-left">

                                                            <span class="text-muted">
                                                                <?php echo e(__('checkout/checkout.Shipping Fee')); ?>

                                                            </span>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-right">
                                                            <span class="text-danger">
                                                                <?php echo e(number_format(Session::get('fee'), 0 , ',' , '.')); ?> đ
                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php else: ?>
                                                <tr>
                                                    <td>
                                                        <div class="text-left">

                                                            <span class="text-muted">
                                                                <?php echo e(__('checkout/checkout.Shipping Fee')); ?>

                                                            </span>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-right">
                                                            <span class="text-danger">
                                                                0 đ
                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endif; ?>


                                                <tr>
                                                    <td>
                                                        <div class="text-left">

                                                            <span class="text-muted">
                                                                <?php echo e(__('checkout/checkout.Tax Fee')); ?>

                                                            </span>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-right">
                                                            <span class="text-danger">
                                                                <?php echo e(number_format($tax, 0, ',', '.').' '.'đ'); ?>

                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>


                                                <tr>
                                                    <td>
                                                        <div class="text-left">

                                                            <span class="text-muted">
                                                                <?php echo e(__('checkout/checkout.Discount')); ?>

                                                            </span>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-right">
                                                            <span class="text-success">
                                                                <?php echo e(Cart::discount(0 , ',' , '.').' '.'đ'); ?>

                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>


                                                <tr class="border-top border-bottom">
                                                    <td>
                                                        <div class="text-left">

                                                            <span class="font-weight-bold">
                                                                <?php echo e(__('checkout/checkout.Subtotal')); ?>

                                                            </span>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-right">
                                                            <span class="font-weight-bold">
                                                                <?php echo e(number_format($total_all, 0 , ',' , '.')); ?> đ
                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>

                                            </tbody>

                                        </table>

                                    </div>



                                </div>


                                <p>
                                    <?php echo e(__('checkout/checkout.We will be sending shipping confirmation email when the item shipped successfully!')); ?>

                                </p>
                                <p class="font-weight-bold mb-0">
                                    <?php echo e(__('checkout/checkout.Thanks for shopping with us!')); ?>

                                </p>
                                <span>
                                    <?php echo e(__('checkout/checkout.Zay Shop Team')); ?>

                                </span>





                            </div>


                            <div class="d-flex justify-content-between footer p-3">

                                <span>
                                     <?php echo e(__('checkout/checkout.Need Help? visit our')); ?>

                                    <a href="#"> 
                                        <?php echo e(__('checkout/checkout.help center')); ?>

                                    </a>
                                </span>
                                <?php
                                    echo $orderDate->format('d/m/Y');
                                ?>

                            </div>




                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<main class="container">
    <div class="py-5 text-center">
        <h2>
            <?php echo e(__('checkout/checkout.Checkout form')); ?>

        </h2>
    </div>
    <?php if(Cart::count() == 0): ?>
        <h2>
            <?php echo e(__('checkout/checkout.Your cart is still null')); ?>

        </h2>
        <hr style="width: 30%;">
        <a class="btn btn-success" href="<?php echo e(URL::to('/shop')); ?>" role="button">
            <?php echo e(__('checkout/checkout.Shopping now')); ?>

        </a>
        <hr style="width: 30%;">
        <h4>
            <?php echo e(__('checkout/checkout.OR')); ?>

        </h4>
        <hr style="width: 30%;">
        <a class="btn btn-success" href="<?php echo e(URL::to('/shop-cart')); ?>" role="button">
            <?php echo e(__('checkout/checkout.Check your cart')); ?>

        </a>
        <hr style="width: 30%;">
    <?php else: ?>
    <div class="row g-5">
        <div class="col-md-5 col-lg-4 order-md-last">

            <form>
                <?php if(Session::get('fee')): ?>
                <fieldset disabled>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="col-md">
                        <label for="city" class="form-label">
                            <?php echo e(__('checkout/checkout.City')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <select name="city" id="city" class="form-control choose city">
                            <option value="">
                                -----<?php echo e(__('checkout/checkout.Choose your city')); ?>-----
                            </option>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ci->matp); ?>">
                                    <?php echo e($ci->name_city); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md">
                        <label for="state" class="form-label">
                            <?php echo e(__('checkout/checkout.Province')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <select name="province" id="province" class="form-control province choose">
                            <option value="">
                                -----<?php echo e(__('checkout/checkout.Choose your province')); ?>-----
                            </option>
                        </select>
                    </div>

                    <div class="col-md">
                        <label for="state" class="form-label">
                            <?php echo e(__('checkout/checkout.Wards')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <select name="wards" id="wards" class="form-control wards">
                            <option value="">
                                -----<?php echo e(__('checkout/checkout.Choose your wards')); ?>-----
                            </option>
                        </select>
                    </div>
                    <hr class="my-4">
                    <?php if(Session::get('fee')): ?>
                        <div class="col-md">
                            <input type="button" value="<?php echo e(__('checkout/checkout.Calculate delivery')); ?>" 
                                name="calculate_order" class="w-100 btn btn-dark btn-lg calculate_delivery">
                        </div>
                    <?php else: ?>
                        <div class="col-md">
                            <input type="button" value="<?php echo e(__('checkout/checkout.Calculate delivery')); ?>" 
                                name="calculate_order" class="w-100 btn btn-primary btn-lg calculate_delivery">
                        </div>
                    <?php endif; ?>
                    <hr class="my-4">
                    <?php if(Session::get('fee')): ?>
                </fieldset>
                <?php endif; ?>
            </form>
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-primary">
                    <?php echo e(__('checkout/checkout.Check your cart')); ?>

                </span>
                <span class="badge bg-primary rounded-pill">
                    <?php echo e(Cart::count()); ?>

                </span>
            </h4>
            <ul class="list-group mb-3">
                <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between lh-sm">
                    <div>
                        <h6 class="my-0">
                            <?php echo e($value->name); ?>

                        </h6>
                        <small class="text-muted">
                            <?php echo e($value->qty); ?>

                        </small>
                    </div>
                    <span class="text-muted">
                        <?php echo e(number_format($value->price, 0, ',', '.').' '.'đ'); ?>

                    </span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span>
                        <?php echo e(__('checkout/checkout.Sub Total')); ?>

                    </span>
                    <strong>
                        <?php echo e(Cart::pricetotal(0 , ',' , '.').' '.'đ'); ?>

                    </strong>
                </li>
                <li class="list-group-item d-flex justify-content-between bg-light">
                    <div class="text-danger">
                        <h6 class="my-0">
                            <?php echo e(__('checkout/checkout.Tax')); ?>

                        </h6>
                        <small>
                            10% <?php echo e(__('checkout/checkout.cart')); ?>

                        </small>
                    </div>
                    <span class="text-danger">
                        <?php echo e(number_format($tax, 0, ',', '.').' '.'đ'); ?>

                    </span>
                </li>
                <?php if(Session::get('coupon')): ?>
                    <?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cou['coupon_condition']==1): ?>
                            <li class="list-group-item d-flex justify-content-between bg-light">
                                <div class="text-success">
                                    <h6 class="my-0">
                                        <?php echo e(__('checkout/checkout.Promo code')); ?>

                                    </h6>
                                    <small>
                                        <?php 
                                            echo '-' . $cou['coupon_number'] . '% cart' 
                                        ?>
                                    </small>
                                </div>
                                <span class="text-success">
                                    <?php echo e(Cart::discount(0 , ',' , '.').' '.'đ'); ?>

                                </span>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <li class="list-group-item d-flex justify-content-between bg-light">
                        <div class="text-success">
                            <h6 class="my-0">
                                <?php echo e(__('checkout/checkout.Promo code')); ?>

                            </h6>
                            <small>
                                <?php echo e(__('checkout/checkout.NONE')); ?>

                            </small>
                        </div>
                        <span class="text-success">
                            0 đ
                        </span>
                    </li>
                <?php endif; ?>
                <?php if(Session::get('fee')): ?>
                <li class="list-group-item d-flex justify-content-between bg-light">
                    <div class="text-danger">
                        <h6 class="my-0">
                            <?php echo e(__('checkout/checkout.Shipping fee')); ?>

                        </h6>
                    </div>

                    <span class="text-danger">
                        <?php echo e(number_format(Session::get('fee'), 0 , ',' , '.')); ?> đ
                    </span>
                </li>
                <li class="list-group-item d-flex justify-content-between bg-light">
                    <p>
                        <?php echo e(__('checkout/checkout.Delete address here')); ?>

                    </p>
                    <a class="cart_quantity_delete" href="<?php echo e(url('/del-fee')); ?>">
                        <i style="color: red; font-size:120% ;" class="fa fa-xmark"></i>
                    </a>
                </li>
                <?php
                if (Session::get('fee') != null) {
                    $total_after_shipping = Cart::total(0, ',', '') + Session::get('fee');
                }
                ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span>
                        <?php echo e(__('checkout/checkout.Total')); ?>

                    </span>
                    <strong>
                        <?php echo e(number_format($total_after_shipping, 0 , ',' , '.')); ?> đ
                    </strong>
                </li>
                <?php else: ?>
                <li class="list-group-item d-flex justify-content-between bg-light">
                    <div class="text-danger">
                        <h6 class="my-0">
                            <?php echo e(__('checkout/checkout.Shipping fee')); ?>

                        </h6>
                    </div>
                    <span class="text-danger">
                        0 đ
                    </span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span>
                        <?php echo e(__('checkout/checkout.Total')); ?>

                    </span>
                    <strong>
                        <?php echo e(Cart::total(0 , ',' , '.').' '.'đ'); ?>

                    </strong>
                </li>
                <?php endif; ?>
            </ul>

        </div>
        <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">
                <?php echo e(__('checkout/checkout.Billing address')); ?>

            </h4>
            <form method="POST" action="">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-sm-6">
                        <label for="shipping_name" class="form-label">
                            <?php echo e(__('checkout/checkout.Full name')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <input type="text" class="form-control shipping_name" 
                            name="shipping_name" id="shipping_name" 
                                value="<?php echo e(Session::get('account_name')); ?>">
                    </div>

                    <div class="col-12">
                        <label for="shipping_email" class="form-label">
                            <?php echo e(__('checkout/checkout.Email')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <input readonly type="email" class="form-control shipping_email" 
                            name="shipping_email" id="shipping_email" 
                                value="<?php echo e(Session::get('account_email')); ?>">
                    </div>

                    <div class="col-12">
                        <label for="shipping_address" class="form-label">
                            <?php echo e(__('checkout/checkout.Address')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <input type="text" class="form-control shipping_address" 
                            name="shipping_address" id="shipping_address" 
                                placeholder="Where ur house?..." value="<?php echo e(Session::get('account_address')); ?>">
                    </div>

                    <div class="col-12">
                        <label for="shipping_phone" class="form-label">
                            <?php echo e(__('checkout/checkout.Phone')); ?>

                        </label>
                        <strong style="color: red;">*</strong>
                        <input readonly type="text" class="form-control shipping_phone" 
                            name="shipping_phone" id="shipping_phone" 
                                value="<?php echo e(Session::get('account_phone')); ?>">
                    </div>

                    <div class="col-12">
                        <label for="shipping_notes" class="form-label">
                            <?php echo e(__('checkout/checkout.Delivery note')); ?>

                        </label>
                        <span class="text-muted">
                            <?php echo e(__('checkout/checkout.(Optional)')); ?>

                        </span>
                        <textarea rows="5" type="text" class="form-control shipping_notes" 
                            name="shipping_notes" id="shipping_notes" 
                                placeholder="<?php echo e(__('checkout/checkout.Wanna note something for delivery man?...')); ?>"></textarea>
                    </div>
                </div>
                <?php if(Session::get('fee')): ?>
                    <input type="hidden" name="order_fee" class="order_fee" value="<?php echo e(Session::get('fee')); ?>">
                <?php else: ?>
                <?php endif; ?>

                <?php if(Session::get('coupon')): ?>
                    <?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="order_coupon" class="order_coupon" value="<?php echo e($cou['coupon_code']); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <input type="hidden" name="order_coupon" class="order_coupon" value="no">
                <?php endif; ?>
                </br>
                <h6 style="color: red;">
                <strong>
                    * Note:
                </strong>
                <span>If you choose paypal as a payment gate, those red "*" above would be saved follow your paypal information</span>
                </h6>
                <hr class="my-4">

                <h4 class="mb-3">
                    <?php echo e(__('checkout/checkout.Payment')); ?>

                </h4>

                <div class="my-3">
                    <div class="form-check">
                        <input id="cod" name="payment_select" type="radio" class="form-check-input payment_select" value="1">
                        <label class="form-check-label" for="cod">
                            COD
                        </label>
                    </div>
                </div>
                <?php if(session()->has('signature')): ?>
                <div class="my-3">
                    <div class="form-check">
                        <input id="momo" name="payment_select" type="radio" class="form-check-input payment_select" value="2" checked>
                        <label class="form-check-label" for="momo">
                            MOMO
                        </label>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(!session()->has('signature')): ?>
                <div class="my-3">
                    <div class="form-check">
                        <input type="hidden" class="total_momo" value="<?php echo e($total_all); ?>">
                        <input id="momo" name="payment_select" type="radio" class="form-check-input payment_select" value="2">
                        <label class="form-check-label" for="momo">
                            MOMO
                        </label>
                    </div>
                </div>
                <?php endif; ?>

                <hr class="my-4">
                <?php if(session()->has('signature')): ?>
                <input id="automate_check_out" name="automate_check_out" class="w-100 btn btn-danger btn-lg automate_check_out" type="button" value="<?php echo e(__('checkout/checkout.Continue to checkout')); ?>">
                <?php endif; ?>
                <?php if(!session()->has('signature')): ?>
                <input id="check_out" name="send_order_cod" class="w-100 btn btn-danger btn-lg check_out_method" type="button" value="<?php echo e(__('checkout/checkout.Continue to checkout')); ?>">
                <?php endif; ?>
                <hr class="my-4">

                <?php if(Session::get('fee')): ?>
                    <?php
                        $total_usd = ($total_all - Session::get('fee'))/23000;
                    ?>
                <?php else: ?>
                    <?php
                        $total_usd = $total_all/23000;
                    ?>
                <?php endif; ?>

                <div class="container">
                    <div class="row">
                        <div class="col-6">
                            <img src="https://banhxegiatot.com/wp-content/uploads/2021/04/2887b4_3d2a6145f5534541be0340302a614812_mv2.gif" alt="">
                        </div>
                        <div class="col-6">
                            <center>
                                <h4>
                                    Free ship with Paypal
                                </h4>
                            </center>
                            <div id="smart-button-container">
                            <div style="text-align: center;">
                                <div id="paypal-button-container"></div>
                                <input type="hidden" id="total_usd" value="<?php echo e(round($total_usd, 2)); ?>">
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <hr class="my-4">
        </div>
    </div>
    <?php endif; ?>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.public_layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/checkout/shop_checkout.blade.php ENDPATH**/ ?>