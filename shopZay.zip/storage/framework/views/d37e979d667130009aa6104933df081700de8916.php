
<?php $__env->startSection('content'); ?>


<!-- Open Content -->
<?php if(!$product_details->isEmpty()): ?>
<?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="bg-light">
    <div class="container pb-5">
        <div class="row">
            <div class="col-lg-5 mt-5">
                <div class="card mb-3">
                    <img class="card-img img-fluid" 
                        src="<?php echo e(URL::to('/storage/app/public/products/'.$pro->product_image)); ?>" 
                            alt="Card image cap" id="product-detail">
                </div>
                <div class="row">
                    <!--Start Controls-->
                    <div class="col-1 align-self-center">
                        <a href="#multi-item-example" role="button" data-bs-slide="prev">
                            <i class="text-dark fas fa-chevron-left"></i>
                            <span class="sr-only">
                                Previous
                            </span>
                        </a>
                    </div>
                    <!--End Controls-->
                    <!--Start Carousel Wrapper-->
                    <div id="multi-item-example" class="col-10 carousel slide carousel-multi-item" 
                        data-bs-ride="carousel">
                        <!--Start Slides-->
                        <div class="carousel-inner product-links-wap" role="listbox">

                            <!--First slide-->
                            <div class="carousel-item active">
                                <div class="row">
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(URL::to('/storage/app/public/products/'.$pro->product_image)); ?>" 
                                                    alt="Product Image 1">
                                        </a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_02.jpg')); ?>" 
                                                    alt="Product Image 2">
                                        </a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_03.jpg')); ?>" 
                                                    alt="Product Image 3">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!--/.First slide-->

                            <!--Second slide-->
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_04.jpg')); ?>" 
                                                alt="Product Image 4">
                                        </a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_05.jpg')); ?>" 
                                                alt="Product Image 5">
                                        </a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_06.jpg')); ?>" 
                                                alt="Product Image 6">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!--/.Second slide-->

                            <!--Third slide-->
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_07.jpg')); ?>" 
                                                    alt="Product Image 7">
                                        </a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_08.jpg')); ?>" 
                                                    alt="Product Image 8">
                                        </a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#">
                                            <img class="card-img img-fluid" 
                                                src="<?php echo e(asset('public/frontend/images/product_single_09.jpg')); ?>" 
                                                    alt="Product Image 9">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!--/.Third slide-->
                        </div>
                        <!--End Slides-->
                    </div>
                    <!--End Carousel Wrapper-->
                    <!--Start Controls-->
                    <div class="col-1 align-self-center">
                        <a href="#multi-item-example" role="button" data-bs-slide="next">
                            <i class="text-dark fas fa-chevron-right"></i>
                            <span class="sr-only">
                                Next
                            </span>
                        </a>
                    </div>
                    <!--End Controls-->
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-7 mt-5">
                <div class="card">
                    <div class="card-body">
                        <h1 class="h2">
                            <?php echo e($pro->product_name); ?>

                        </h1>
                        <p class="h3 py-2">
                            <?php echo e(number_format($pro->product_price, 0, ',' , '.').' '.'VNĐ'); ?>

                        </p>
                        <p class="py-2">
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <span class="list-inline-item text-dark">
                                <?php echo e(__('public/shop.Rating')); ?> 5.0 | 36 <?php echo e(__('public/shop.Comments')); ?>

                            </span>
                        </p>
                        <ul class="list-inline">
                            <li class="list-inline-item">
                                <h6>
                                    <?php echo e(__('public/shop.Subcategory:')); ?>

                                </h6>
                            </li>
                            <li class="list-inline-item">
                                <p class="text-muted">
                                    <strong>
                                        <?php echo e($pro->subcategory_name); ?>

                                    </strong>
                                </p>
                            </li>
                        </ul>

                        <h6>
                            <?php echo e(__('public/shop.Description:')); ?>

                        </h6>
                        <p>
                            <?php echo $pro->product_desc; ?>

                        </p>

                        <h6>
                            <?php echo e(__('public/shop.Content:')); ?>

                        </h6>
                        <ul class="list-unstyled pb-3">
                            <li>
                                <?php echo $pro->product_content; ?>

                            </li>
                        </ul>

                        <h6>
                            <?php echo e(__('public/shop.Product available in stock:')); ?>

                        </h6>
                        <ul class="list-unstyled pb-3">
                            <li>
                                <?php echo e($pro->product_quantity); ?>

                            </li>
                        </ul>
                        <form action="<?php echo e(URL::to('/save-cart')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="form-outline">
                                        <h6>
                                            <?php echo e(__('public/shop.Quantity:')); ?>

                                        </h6>
                                        <input type="number" id="qty" 
                                            name="qty" class="form-control" min="1" value="1"/>
                                        <input type="hidden" 
                                            name="productid_hidden" value="<?php echo e($pro->product_id); ?>"/>
                                    </div>
                                </div>
                            </div>
                            </br>
                            <div class="row pb-3">
                                <div class="col d-grid">
                                    <button type="submit" class="btn btn-success btn-lg" 
                                        name="submit" value="addtocard">
                                        <?php echo e(__('public/shop.Add To Cart')); ?>

                                    </button>
                                </div>
                                <div class="col d-grid">
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Close Content -->

<!-- Start Article -->
<section class="py-5">
    <div class="container">
        <div class="row text-left p-2 pb-3">
            <h4>
                <?php echo e(__('public/shop.Related Products')); ?>

            </h4>
        </div>

        <!--Start Carousel Wrapper-->
        
    <?php if(!$related_product->isEmpty()): ?>
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-wap card rounded-0">
                    <div class="card rounded-0">
                        <a href="<?php echo e(URL::to('/product-details/'.$relate->product_id)); ?>">
                            <img class="card-img rounded-0 img-fluid" 
                                src="<?php echo e(URL::to('/public/upload/product/'.$relate->product_image)); ?>">
                        </a>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(URL::to('/product-details/'.$relate->product_id)); ?>" class="h3 text-decoration-none">
                            <?php echo e($relate->product_name); ?>

                        </a>
                        <ul class="list-unstyled d-flex justify-content-center mb-1">
                            <li>
                                <i class="text-warning fa fa-star"></i>
                                <i class="text-warning fa fa-star"></i>
                                <i class="text-warning fa fa-star"></i>
                                <i class="text-warning fa fa-star"></i>
                                <i class="text-warning fa fa-star"></i>
                            </li>
                        </ul>
                        <p class="text-center mb-0">
                            <?php echo e(number_format($relate->product_price, 0, ',' , '.').' '.'VNĐ'); ?>

                        </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    </div>
</section>
<?php else: ?>
<center>
    <h1 class="m-5">
        Nothing here
    </h1>
</center>
<?php endif; ?>
<!-- End Article -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.public_layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/product/shop_details.blade.php ENDPATH**/ ?>