
<?php $__env->startSection('content'); ?>


<!-- Start Content -->
<div class="container py-5">
    <div class="row">

        <div class="col-lg-3">
            <h1 class="h2 pb-4"><?php echo e(__('public/shop.Categories')); ?></h1>
            <ul class="list-unstyled templatemo-accordion">
                <?php if(!$category->isEmpty()): ?>
                <li class="pb-3">
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="collapsed d-flex justify-content-between h3 text-decoration-none" href="<?php echo e(URL::to('/category/'.$cate->category_id)); ?>">
                        <?php echo e($cate->category_name); ?>

                        <i class="fa fa-fw fa-chevron-circle-down mt-1"></i>
                    </a>
                    <ul class="collapse show list-unstyled pl-3">
                        <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cate->category_id == $sub->category_id): ?>
                        <li><a class="text-decoration-none" href="<?php echo e(URL::to('/subcategory/'.$sub->subcategory_id)); ?>"><?php echo e($sub->subcategory_name); ?></a></li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <?php else: ?>
                <li aria-disabled="true">
                    <?php echo e(__('public/shop.No category available')); ?>

                </li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="col-lg-9">
            <div class="row">
                <div class="col-md-6">
                    <!-- <ul class="list-inline shop-top-menu pb-3 pt-1">
                        <li class="list-inline-item">
                            <a class="h3 text-dark text-decoration-none mr-3" href="#">All</a>
                        </li>
                        <li class="list-inline-item">
                            <a class="h3 text-dark text-decoration-none mr-3" href="#">Men's</a>
                        </li>
                        <li class="list-inline-item">
                            <a class="h3 text-dark text-decoration-none" href="#">Women's</a>
                        </li>
                    </ul> -->
                </div>
                <div class="col-md-6 pb-4">
                    <form>
                        <div class="d-flex">
                            <?php echo csrf_field(); ?>
                            <select name="sort" id="sort" class="form-control">
                                <option value="<?php echo e(Request::url()); ?>?sort_by=none"><?php echo e(__('public/shop.Sort product')); ?></option>
                                <option value="<?php echo e(Request::url()); ?>?sort_by=desc" <?php echo e(Request::fullurl() == Request::url().'?sort_by=desc' ? "selected" : ""); ?>><?php echo e(__('public/shop.Descending')); ?></option>
                                <option value="<?php echo e(Request::url()); ?>?sort_by=asc" <?php echo e(Request::fullurl() == Request::url().'?sort_by=asc' ? "selected" : ""); ?>><?php echo e(__('public/shop.Ascending')); ?></option>
                                <option value="<?php echo e(Request::url()); ?>?sort_by=atoz" <?php echo e(Request::fullurl() == Request::url().'?sort_by=atoz' ? "selected" : ""); ?>><?php echo e(__('public/shop.A to Z')); ?></option>
                                <option value="<?php echo e(Request::url()); ?>?sort_by=ztoa" <?php echo e(Request::fullurl() == Request::url().'?sort_by=ztoa' ? "selected" : ""); ?>><?php echo e(__('public/shop.Z to A')); ?></option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
            <?php if(!$subcategory_by_id->isEmpty()): ?>
                <?php $__currentLoopData = $subcategory_by_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4 product-wap rounded-0">
                        <div class="card rounded-0">
                            <img class="card-img rounded-0 img-fluid" src="<?php echo e(URL::to('/storage/app/public/products/'.$pro->product_image)); ?>">
                            <div class="card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center">
                                <ul class="list-unstyled">
                                    <li><a class="btn btn-success text-white" href="#"><i class="far fa-heart"></i></a></li>
                                    <li><a class="btn btn-success text-white mt-2" href="<?php echo e(URL::to('/product-details/'.$pro->product_id)); ?>"><i class="far fa-eye"></i></a></li>
                                    <li><a class="btn btn-success text-white mt-2" href="#"><i class="fas fa-cart-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body">
                            <a href="<?php echo e(URL::to('/product-details/'.$pro->product_id)); ?>" class="h3 text-decoration-none"><?php echo e($pro->product_name); ?></a>
                            <ul class="w-100 list-unstyled d-flex justify-content-between mb-0">
                                <li class="pt-2">
                                    <span class="product-color-dot color-dot-red float-left rounded-circle ml-1"></span>
                                    <span class="product-color-dot color-dot-blue float-left rounded-circle ml-1"></span>
                                    <span class="product-color-dot color-dot-black float-left rounded-circle ml-1"></span>
                                    <span class="product-color-dot color-dot-light float-left rounded-circle ml-1"></span>
                                    <span class="product-color-dot color-dot-green float-left rounded-circle ml-1"></span>
                                </li>
                            </ul>
                            <ul class="list-unstyled d-flex justify-content-center mb-1">
                                <li>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                </li>
                            </ul>
                            <p class="text-center mb-0"><?php echo e(number_format($pro->product_price, 0, ',' , '.').' '.'VNĐ'); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <center>
                    <h3>
                        No product here
                    </h3>
                </center>
            <?php endif; ?>
            </div>
            <?php echo $subcategory_by_id->render('components.public_paginate.pagination'); ?>

        </div>

    </div>
</div>
<!-- End Content -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.public_layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/subcategory/shop_subcategory.blade.php ENDPATH**/ ?>