
<?php $__env->startSection('admin_content'); ?>

<!-- Alert -->
<?php if(session()->has('message')): ?>
<div class="container">
    <div class="row">
        <div class="col-9"></div>
        <div class="col-sm-3">
            <div id="alertMessage" class="alert alert-success">
                <strong>Success! </strong>
                <?php echo e(session()->get('message')); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php
Session::put('message', null);
?>
<?php elseif(session()->has('error')): ?>
<div class="container">
    <div class="row">
        <div class="col-9"></div>
        <div class="col-sm-3">
            <div id="alertMessage" class="alert alert-danger">
                <strong>Error! </strong>
                <?php echo e(session()->get('error')); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php
Session::put('error', null);
?>
<?php endif; ?>
<!-- End Alert -->

<div class="container">
    <div class="col-lg-11">
        <?php $__currentLoopData = $edit_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>Edit product: <?php echo e($edit_value->product_name); ?></h6>
                    </div>
                    <div class="col-lg-6 col-5 my-auto text-end">
                        <div class="dropdown float-lg-end pe-4">
                            <a class="cursor-pointer" id="dropdownTable" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-secondary"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="col-md-7 container">
                    <form role="form" method="POST" action="<?php echo e(URL::to('/update-product/'.$edit_value->product_id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">Product Name</label>
                            <input value="<?php echo e($edit_value->product_name); ?>" name="product_name" type="text" class="form-control">
                        </div>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">Product Quantity</label>
                            <input value="<?php echo e($edit_value->product_quantity); ?>" name="product_quantity" type="text" class="form-control">
                        </div>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">Product Price</label>
                            <input value="<?php echo e($edit_value->product_price); ?>" name="product_price" type="text" class="form-control">
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <div class="col-md-3">
                                <span class="form-label">Product Image</span>
                            </div>
                            <div class="col-md-9">
                                <input name="product_image" type="file" class="form-control" id="productImage" onchange="preview()">
                            </div>
                            
                            <img id="frame" src="../public/upload/product/<?php echo e($edit_value->product_image); ?>" width="200" alt="No image available" />
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <label class="form-label" for="ckeditorAdd">Product Description</label>
                            <textarea name="product_desc" placeholder="Enter Product Description" class="form-control" id="ckeditorAdd" rows="8"> <?php echo e($edit_value->product_desc); ?> </textarea>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <label class="form-label" for="ckeditorAdd1">Product Content</label>
                            <textarea name="product_content" placeholder="Enter Product Content" class="form-control" id="ckeditorAdd1" rows="8"> <?php echo e($edit_value->product_content); ?> </textarea>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <select name="category" id="category" class="form-control choose category">
                                <option value="">Choose your category</option>
                                <?php $__currentLoopData = $get_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($get_category->category_id); ?>" <?php echo e($get_category->category_id == $edit_value->category_id?'selected':''); ?>><?php echo e($get_category->category_name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <select name="subcategory" id="subcategory" class="form-control subcategory choose">
                                <?php $__currentLoopData = $get_subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get_subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($get_subcategory->subcategory_id); ?>" <?php echo e($get_subcategory->subcategory_id == $edit_value->subcategory_id?'selected':''); ?>><?php echo e($get_subcategory->subcategory_name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">Save product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/edit_product.blade.php ENDPATH**/ ?>