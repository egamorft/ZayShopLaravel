
<?php $__env->startSection('admin_content'); ?>
<div id="vue">
    <category></category>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/category/show_category.blade.php ENDPATH**/ ?>