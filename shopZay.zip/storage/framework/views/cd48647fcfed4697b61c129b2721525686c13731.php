
<?php $__env->startSection('admin_content'); ?>


<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <h6 class="text-white text-capitalize ps-3">
                            Category table
                        </h6>
                    </div>
                </div>
                <div class="col-11 text-end">
                    <a href="<?php echo e(URL::to('/add-category')); ?>" class="btn bg-gradient-dark mb-0">
                        <i class="material-icons text-sm">
                            add
                        </i>&nbsp;&nbsp;
                        Add Category
                    </a>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">
                                        ID
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Category Name
                                    </th>
                                    <th class="text-center text-uppercase text-secondary font-weight-bolder opacity-7">
                                        Show/Hide
                                    </th>
                                    <th class="text-secondary opacity-7"></th>
                                    <th class="text-secondary opacity-7"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $show_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex px-2 py-1">
                                            <div class="justify-content-center">
                                                <?php echo e($cate->category_id); ?>

                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($cate->category_name); ?>

                                        </p>
                                    </td>

                                    <td class="align-middle text-center">
                                        <?php
                                        if ($cate->category_status == 1) {
                                        ?>
                                            <a onclick="return confirm('This action also unactive their subcategory and product status. Continue?')" 
                                                href="<?php echo e(URL::to('/unactive-category/'.$cate->category_id)); ?>">
                                                    <i class="material-icons" style="font-size: 40px; color:green;">
                                                        thumb_up
                                                    </i>
                                            </a>
                                        <?php
                                        } else {
                                        ?>
                                            <a href="<?php echo e(URL::to('/active-category/'.$cate->category_id)); ?>">
                                                <i class="material-icons" style="font-size: 40px; color:red;">
                                                    thumb_down
                                                </i>
                                            </a>
                                        <?php
                                        }
                                        ?>
                                    </td>
                                    <td class="align-middle">
                                        <a href="<?php echo e(URL::to('/edit-category/'.$cate->category_id)); ?>" class="font-weight-bold" data-toggle="tooltip">
                                            <i class="material-icons" style="font-size: 30px;">
                                                edit
                                            </i>
                                        </a>
                                    </td>
                                    <td class="align-middle">
                                        <a onclick="return confirm('Are you sure to delete?')" 
                                            href="<?php echo e(URL::to('/delete-category/'.$cate->category_id)); ?>" class="font-weight-bold" data-toggle="tooltip">
                                            <i class="material-icons" style="font-size: 30px;">
                                                delete
                                            </i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo $show_category->render('components.admin_paginate.admin_pagination'); ?>

        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/show_category.blade.php ENDPATH**/ ?>