<?php if($paginator->hasPages()): ?>
<!-- Pagination -->
<div div="row">
    <ul class="pagination pagination-lg justify-content-end">
        
        <?php if($paginator->onFirstPage()): ?>
        <li class="page-item disabled" aria-disabled="true" aria-label="&laquo; Previous">
            <span class="page-link" aria-hidden="true">&lsaquo;</span>
        </li>
        <?php else: ?>
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="&laquo; Previous">&lsaquo;</a>
        </li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if(is_array($element)): ?>
        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($page == $paginator->currentPage()): ?>
        <li class="page-item disabled">
            <a class="page-link active rounded-0 mr-3 shadow-sm border-top-0 border-left-0" href="#"><?php echo e($page); ?></a>
        </li>
        <?php else: ?>
        <li class="page-item">
            <a class="page-link rounded-0 mr-3 shadow-sm border-top-0 border-left-0 text-dark" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Next Page Link -->
        <?php if($paginator->hasMorePages()): ?>
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="Next &raquo;">&rsaquo;</a>
        </li>
        <?php else: ?>
        <li class="page-item disabled" aria-disabled="true" aria-label="Next &raquo;">
            <span class="page-link" aria-hidden="true">&rsaquo;</span>
        </li>
        <?php endif; ?>
        <!-- Next Page Link -->
    </ul>
</div>
<!-- Pagination -->
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/public/pagination.blade.php ENDPATH**/ ?>