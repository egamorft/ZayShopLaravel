
<?php $__env->startSection('admin_content'); ?>


<div class="container-fluid">
    <div class="col-11 text-start">
        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($or->order_status == 2): ?>
        <a target="_blank" href="<?php echo e(URL::to('/print-bill/'.$details->order_code)); ?>" class="btn bg-gradient-dark mb-0">
            <i class="material-icons text-sm">
                print
            </i>&nbsp;&nbsp;
            Print bill
        </a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container-fluid py-2">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <h6 class="text-white text-capitalize ps-3">
                            Customer information
                        </h6>
                    </div>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">
                                        Customer name
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Customer phone
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Customer email
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <p class="font-weight-bold d-flex px-2 py-1">
                                            <?php echo e($account->account_name); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($account->account_phone); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($account->account_email); ?>

                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-2">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <h6 class="text-white text-capitalize ps-3">
                            Shipping information
                        </h6>
                    </div>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">
                                        Shipping to
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Shipping address
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Phone number
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Email
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Shipping notes
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Shipping method
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <p class="font-weight-bold d-flex px-2 py-1">
                                            <?php echo e($shipping->shipping_name); ?>


                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($shipping->shipping_address); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($shipping->shipping_phone); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($shipping->shipping_email); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($shipping->shipping_notes); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <?php if($shipping->shipping_method == 1): ?>
                                        <p class="font-weight-bold mb-0">
                                            COD
                                        </p>
                                        <?php elseif($shipping->shipping_method == 2): ?>
                                        <p class="font-weight-bold mb-0">
                                            MOMO
                                        </p>
                                        <?php elseif($shipping->shipping_method == 3): ?>
                                        <p class="font-weight-bold mb-0">
                                            PAYPAL
                                        </p>
                                        <?php else: ?>
                                        <p class="font-weight-bold mb-0">
                                            Unidentified
                                        </p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-2">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <h6 class="text-white text-capitalize ps-3">
                            Order details
                        </h6>
                    </div>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7">

                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Product name</th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Product in stock
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Coupon
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Fee ship
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Quantity
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Product price
                                    </th>
                                    <th class="text-uppercase text-secondary font-weight-bolder opacity-7 ps-2">
                                        Subtotal
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 0;
                                $total = 0;
                                ?>
                                <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $i++;
                                $subtotal = $details->product_price * $details->product_sales_quantity;
                                $total += $subtotal;
                                ?>
                                <tr class="color_qty_<?php echo e($details->product_id); ?>">
                                    <td>
                                        <div class="d-flex px-2 py-1">
                                            <div class="justify-content-center">
                                                <?php echo e($i); ?>

                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($details->product_name); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($details->product->product_quantity); ?>

                                        </p>
                                    </td>
                                    <td>

                                        <?php if($details->product_coupon != 'no'): ?>

                                        <p class="font-weight-bold mb-0">
                                            <?php echo e($details->product_coupon); ?>

                                        </p>
                                        <?php else: ?>

                                        <p class="font-weight-italic mb-0">
                                            NULL
                                        </p>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e(number_format($details->product_feeship, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <input <?php echo e($order_status == 2 || $order_status == 4 ?"disabled":''); ?> type="number" class="order_qty_<?php echo e($details->product_id); ?>" min="1" value="<?php echo e($details->product_sales_quantity); ?>" name="product_sales_quantity">

                                            <input type="hidden" name="order_qty_storage" class="order_qty_storage_<?php echo e($details->product_id); ?>" value="<?php echo e($details->product->product_quantity); ?>">

                                            <input type="hidden" name="order_code" class="order_code" value="<?php echo e($details->order_code); ?>">

                                            <input type="hidden" name="order_product_id" class="order_product_id" value="<?php echo e($details->product_id); ?>">
                                            <?php if($order_status == 2 || $order_status == 4 ): ?>
                                            <button disabled data-product_id="<?php echo e($details->product_id); ?>" name="update_quantity_order" class="btn btn-dark update_quantity_order">
                                                Update
                                            </button>
                                            <?php else: ?>
                                            <button data-product_id="<?php echo e($details->product_id); ?>" name="update_quantity_order" class="btn btn-success update_quantity_order">
                                                Update
                                            </button>
                                            <?php endif; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e(number_format($details->product_price, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                    <td>
                                        <p class="font-weight-bold mb-0">
                                            <?php echo e(number_format($subtotal, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php
                                    $total_coupon = 0;
                                    $tax = $total * 10 / 100;
                                    ?>
                                    <?php if($coupon_condition): ?>
                                    <?php if($coupon_condition == 1): ?>
                                    <?php
                                    $total_coupon = $total - (($coupon_number/100) * $total) + $details->product_feeship + $tax
                                    ?>
                                    <?php else: ?>
                                    <?php
                                    $total_coupon = $total - $coupon_number + $details->product_feeship + $tax
                                    ?>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <p class="text-success font-weight-bold mb-0">
                                            SubTotal: <?php echo e(number_format($total, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                    <td>
                                        <p class="text-danger font-weight-bold mb-0">
                                            Tax: <?php echo e(number_format($tax, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                    <td>
                                        <p class="text-danger font-weight-bold mb-0">
                                            Fee ship:<?php echo e(number_format($details->product_feeship, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                    <td>
                                        <p class="text-success font-weight-bold mb-0">
                                            Coupon discount:<?php echo e(number_format(($coupon_number/100) * $total, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                    <td>
                                        <p class="text-success font-weight-bold mb-0">
                                            Total bill: <?php echo e(number_format($total_coupon, 0 , ',' , '.')); ?>đ
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($or->order_status==1): ?>
                                        <form class="input-group input-group-outline mb-3">
                                            <?php echo csrf_field(); ?>
                                            <select class="form-control order_details">
                                                <option id="<?php echo e($or->order_id); ?>" value="1" selected>
                                                    --------Choose order status--------
                                                </option>
                                                <option id="<?php echo e($or->order_id); ?>" value="2">
                                                    Delivering
                                                </option>
                                                <option id="<?php echo e($or->order_id); ?>" value="3">
                                                    Cancel/ Pending order
                                                </option>
                                            </select>
                                        </form>
                                        <?php elseif($or->order_status==2): ?>
                                        <form class="input-group input-group-outline mb-3">
                                            <?php echo csrf_field(); ?>
                                            <select class="form-control order_details">
                                                <option id="<?php echo e($or->order_id); ?>" value="2" selected>
                                                    Delivering
                                                </option>
                                                <option id="<?php echo e($or->order_id); ?>" value="3">
                                                    Cancel/ Pending order
                                                </option>
                                            </select>
                                        </form>
                                        <?php elseif($or->order_status==3): ?>

                                        <form class="input-group input-group-outline mb-3">
                                            <?php echo csrf_field(); ?>
                                            <select class="form-control order_details">
                                                <option id="<?php echo e($or->order_id); ?>" value="2">
                                                    Delivering
                                                </option>
                                                <option id="<?php echo e($or->order_id); ?>" value="3" selected>
                                                    Cancel/ Pending order
                                                </option>
                                            </select>
                                        </form>
                                        <?php elseif($or->order_status==4): ?>

                                        <select disabled class="form-control order_details">
                                            <option>
                                                Completed
                                            </option>
                                        </select>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/order/view_order.blade.php ENDPATH**/ ?>