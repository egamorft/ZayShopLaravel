
<?php $__env->startSection('admin_content'); ?>


<div class="container">
    <div class="col-lg-11">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>
                            <?php echo e(__('admin/product.Add product')); ?>

                        </h6>
                    </div>
                    <div class="col-lg-6 col-5 my-auto text-end">
                        <div class="dropdown float-lg-end pe-4">
                            <a class="cursor-pointer" id="dropdownTable" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-secondary"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="col-md-7 container">
                    <form role="form" method="POST" action="<?php echo e(URL::to('/save-product')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">
                                <?php echo e(__('admin/product.Product Name')); ?>

                            </label>
                            <input name="product_name" type="text" class="form-control" value="<?php echo e(old('product_name')); ?>">
                        </div>
                        <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">
                                <?php echo e(__('admin/product.Product Quantity')); ?>

                            </label>
                            <input name="product_quantity" type="text" class="form-control" value="<?php echo e(old('product_quantity')); ?>">
                        </div>
                        <?php $__errorArgs = ['product_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">
                                <?php echo e(__('admin/product.Product Price')); ?>

                            </label>
                            <input name="product_price" type="text" class="form-control" value="<?php echo e(old('product_price')); ?>">
                        </div>
                        <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group input-group-outline mb-3">
                            <div class="col-md-3">
                                <span class="form-label">
                                    <?php echo e(__('admin/product.Product Image')); ?>

                                </span>
                            </div>
                            <div class="col-md-9">
                                <input name="product_image" type="file" class="form-control">
                            </div>
                        </div>
                        <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group input-group-outline mb-3">
                            <label class="form-label" for="ckeditorAdd">
                                <?php echo e(__('admin/product.Product Description')); ?>

                            </label>
                            <textarea name="product_desc" placeholder="<?php echo e(__('admin/product.Enter Product Description')); ?>" 
                                    class="form-control" id="ckeditorAdd" 
                                    rows="8"><?php echo e(old('product_desc')); ?></textarea>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <label class="form-label" for="ckeditorAdd">
                                <?php echo e(__('admin/product.Product Content')); ?>

                            </label>
                            <textarea name="product_content" placeholder="<?php echo e(__('admin/product.Enter Product Content')); ?>" 
                                    class="form-control" id="ckeditorAdd1" 
                                    rows="8"><?php echo e(old('product_content')); ?></textarea>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <select name="category" id="category" class="form-control choose category">
                                <option value="">
                                    <?php echo e(__('admin/product.Choose your category')); ?>

                                </option>
                                <?php if(!$get_category->isEmpty()): ?>
                                <?php $__currentLoopData = $get_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($get_category->category_id); ?>" >
                                        <?php echo e($get_category->category_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <option disabled>
                                    <?php echo e(__('admin/product.Something went wrong')); ?>

                                </option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red">
                            <?php echo e($message); ?>

                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group input-group-outline mb-3">
                            <select name="subcategory" id="subcategory" class="form-control subcategory choose">

                            </select>
                        </div>
                        <?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red">
                            <?php echo e($message); ?>

                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-check mb-3 ">
                            <label class="form-check-label" for="show">
                                <?php echo e(__('admin/product.Show')); ?>

                            </label>
                            <input class="form-check-input" type="radio" name="product_status" id="show" value="1" checked>
                            <label class="form-check-label" for="hide">
                                <?php echo e(__('admin/product.Hide')); ?>

                            </label>
                            <input class="form-check-input" type="radio" name="product_status" id="hide" value="0">
                        </div>
                        <?php $__errorArgs = ['product_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="text-center">
                            <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">
                                <?php echo e(__('admin/product.Add product')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/product/add_product.blade.php ENDPATH**/ ?>