
<?php $__env->startSection('content'); ?>


<div class="content">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="mb-4">
                    <h3><?php echo e(__('public/register.Register to')); ?> <strong style="color: green;"><?php echo e(__('public/register.Zay Shop')); ?></strong></h3>
                </div>
                <form action="<?php echo e(URL::to('/register-account')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating mb-3 mt-3">
                        <input type="text" class="form-control <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="Enter your name" name="account_name" value="<?php echo e(old('account_name')); ?>">
                        <label for="name"><?php echo e(__('public/register.Full name')); ?></label>
                        <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating mb-3 mt-3">
                        <input type="text" class="form-control <?php $__errorArgs = ['account_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Enter email" name="account_email" value="<?php echo e(old('account_email')); ?>">
                        <label for="email"><?php echo e(__('public/register.Email')); ?></label>
                        <?php $__errorArgs = ['account_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating mb-3 mt-3">
                        <input type="text" class="form-control <?php $__errorArgs = ['account_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" placeholder="Enter phone" name="account_phone" value="<?php echo e(old('account_phone')); ?>">
                        <label for="phone"><?php echo e(__('public/register.Phone')); ?></label>
                        <?php $__errorArgs = ['account_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating mb-3 mt-3">
                        <input type="password" class="form-control <?php $__errorArgs = ['account_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="Enter password" name="account_password">
                        <label for="password"><?php echo e(__('public/register.Password')); ?></label>
                        <?php $__errorArgs = ['account_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating mb-3 mt-3">
                        <input type="password" class="form-control <?php $__errorArgs = ['account_cfpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cfpassword" placeholder="Enter confirm password" name="account_cfpassword">
                        <label for="cfpassword"><?php echo e(__('public/register.Confirm Password')); ?></label>
                        <?php $__errorArgs = ['account_cfpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.captcha.captcha_key')); ?>"></div>
                    <br />
                    <?php if($errors->has('g-recaptcha-response')): ?>
                    <span class="invalid-feedback" style="display:block">
                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                    </span>
                    <?php endif; ?>

                    <input type="submit" value="<?php echo e(__('public/register.Sign In')); ?>" class="btn btn-outline-success">

                </form>
                <span class="d-block text-left my-4 text-muted"> <?php echo e(__('public/register.Already have account?')); ?> <a class="text-decoration-none" href="<?php echo e(URL::to('/login')); ?>"> <?php echo e(__('public/register.Log in now')); ?></a></span>

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.public_layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/public/register.blade.php ENDPATH**/ ?>