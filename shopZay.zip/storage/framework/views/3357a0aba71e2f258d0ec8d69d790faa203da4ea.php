
<?php $__env->startSection('admin_content'); ?>


<div class="container">
    <div class="col-lg-11">
    <?php if(!$edit_slider->isEmpty()): ?>
        <?php $__currentLoopData = $edit_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>
                            Edit slider: <?php echo e($edit_value->slider_name); ?>

                        </h6>
                    </div>
                    <div class="col-lg-6 col-5 my-auto text-end">
                        <div class="dropdown float-lg-end pe-4">
                            <a class="cursor-pointer" id="dropdownTable" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-secondary"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="col-md-7 container">
                    <form role="form" method="POST" action="<?php echo e(URL::to('/update-slider/'.$edit_value->slider_id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">
                                Slider Name
                            </label>
                            <input value="<?php echo e($edit_value->slider_name); ?>" name="slider_name" type="text" class="form-control">
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <div class="col-md-3">
                                <span class="form-label">
                                    Slider Image
                                </span>
                            </div>
                            <div class="col-md-9">
                                <input name="slider_image" type="file" class="form-control" id="productImage" onchange="preview()">
                            </div>
                        </div>
                        <img id="frame" src="../public/upload/slider/<?php echo e($edit_value->slider_image); ?>" width="500" alt="No image available" />
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label" for="ckeditorAdd">
                                Slider Description
                            </label>
                            <textarea name="slider_desc" placeholder="Enter Slider Description" class="form-control" id="ckeditorAdd" rows="8">
                                <?php echo e($edit_value->slider_desc); ?> 
                            </textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">
                                Save Slider
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <center>
            <h3>
                Something went wrong
            </h3>
        </center>
    <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/slider/edit_slider.blade.php ENDPATH**/ ?>