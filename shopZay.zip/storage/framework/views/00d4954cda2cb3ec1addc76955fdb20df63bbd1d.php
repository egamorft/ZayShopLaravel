
<?php $__env->startSection('admin_content'); ?>

<!-- Alert -->
<?php if(session()->has('message')): ?>
<div class="container">
    <div class="row">
        <div class="col-9"></div>
        <div class="col-sm-3">
            <div id="alertMessage" class="alert alert-success">
                <strong>Success! </strong>
                <?php echo e(session()->get('message')); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php
Session::put('message', null);
?>
<?php elseif(session()->has('error')): ?>
<div class="container">
    <div class="row">
        <div class="col-9"></div>
        <div class="col-sm-3">
            <div id="alertMessage" class="alert alert-danger">
                <strong>Error! </strong>
                <?php echo e(session()->get('error')); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php
Session::put('error', null);
?>
<?php endif; ?>
<!-- End Alert -->

<div class="container">
    <div class="col-lg-11">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>Add slider</h6>
                    </div>
                    <div class="col-lg-6 col-5 my-auto text-end">
                        <div class="dropdown float-lg-end pe-4">
                            <a class="cursor-pointer" id="dropdownTable" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-secondary"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="col-md-7 container">
                    <form role="form" method="POST" action="<?php echo e(URL::to('/save-slider')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">Slider Name</label>
                            <input name="slider_name" type="text" class="form-control">
                        </div>
                        <?php $__errorArgs = ['slider_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group input-group-outline mb-3">
                            <div class="col-md-3">
                                <span class="form-label">Slider Image</span>
                            </div>
                            <div class="col-md-9">
                                <input name="slider_image" type="file" class="form-control">
                            </div>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <label class="form-label" for="ckeditorAdd">Slider Description</label>
                            <textarea name="slider_desc" placeholder="Enter Slider Description" class="form-control" id="ckeditorAdd" rows="8"></textarea>
                        </div>
                        <div class="form-check mb-3 ">
                            <label class="form-check-label" for="show">Show</label>
                            <input class="form-check-input" type="radio" name="slider_status" id="show" value="1" checked>
                            <label class="form-check-label" for="hide">Hide</label>
                            <input class="form-check-input" type="radio" name="slider_status" id="hide" value="0">
                        </div>
                        <?php $__errorArgs = ['slider_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="text-center">
                            <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">Add slider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/slider/add_slider.blade.php ENDPATH**/ ?>