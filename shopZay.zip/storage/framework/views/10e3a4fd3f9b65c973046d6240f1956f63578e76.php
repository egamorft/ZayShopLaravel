
<?php $__env->startSection('content'); ?>


<?php $__env->startSection('userDashboard'); ?>

<!-- flot charts css-->
<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/user-dashboard.css')); ?>">

<?php $__env->stopSection(); ?>
<!-- Start Content -->
<div class="container mt-4">
    <div class="row">
        <div class="col-lg-3 my-lg-0 my-md-1">
            <div id="sidebar" class="bg-green">
                <div class="h4 text-white"><?php echo e(__('profile/UserProfile.Account')); ?></div>
                <ul>
                    <li class="<?php echo e(Route::currentRouteNamed('profile.account') ? 'active' : ''); ?>"">
                        <a href=" <?php echo e(URL::to('/profile/account')); ?>" class="text-decoration-none d-flex align-items-start">
                        <div class="far pt-2 me-3">
                            <i class="fa-solid fa-user fa-xl"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <div class="link"><?php echo e(__('profile/UserProfile.My Profile')); ?></div>
                            <div class="link-desc"><?php echo e(__('profile/UserProfile.Change your profile')); ?></div>
                        </div>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::currentRouteNamed('profile.chgpwd') ? 'active' : ''); ?>"">
                        <a href=" <?php echo e(URL::to('/profile/chgpwd')); ?>" class="text-decoration-none d-flex align-items-start">
                        <div class="fas pt-2 me-3">
                            <i class="fa-solid fa-lock fa-xl"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <div class="link"><?php echo e(__('profile/UserProfile.Password')); ?></div>
                            <div class="link-desc"><?php echo e(__('profile/UserProfile.Change your password')); ?></div>
                        </div>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::currentRouteNamed('profile.order') ? 'active' : ''); ?>"">
                        <a href=" <?php echo e(URL::to('/profile/order')); ?>" class="text-decoration-none d-flex align-items-start">
                        <div class="fas pt-2 me-3">
                            <i class="fa-solid fa-box fa-xl"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <div class="link"><?php echo e(__('profile/UserProfile.My Order')); ?></div>
                            <div class="link-desc"><?php echo e(__('profile/UserProfile.View & Manage your orders')); ?></div>
                        </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <?php if(Session::get('account_id')): ?>
        <div class="col-lg-9 my-lg-0 my-1">
            <div id="main-content" class="bg-white border row">
                <div class="col-md-3 border-right">
                    <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg">
                    </div>
                </div>
                <div class="col-md-9 border-right">
                    <form action="<?php echo e(URL::to('/save-profile')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="p-3 py-5">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="text-right"><?php echo e(__('profile/UserProfile.Profile Settings')); ?></h4>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12"><label class="labels"><?php echo e(__('profile/UserProfile.Full Name')); ?></label>
                                    <input name="account_name" type="text" class="form-control" value="<?php echo Session::get('account_name') ?>">
                                </div>
                                <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="account_email_check" type="hidden" class="form-control" value="<?php echo Session::get('account_email') ?>">
                                <div class="col-md-12"><label class="labels"><?php echo e(__('profile/UserProfile.Email')); ?></label>
                                    <input readonly name="account_email" type="text" class="form-control" value="<?php echo Session::get('account_email') ?>">
                                </div>
                                <?php $__errorArgs = ['account_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <div class="col-md-12"><label class="labels"><?php echo e(__('profile/UserProfile.Address')); ?></label>
                                    <input name="account_address" type="text" class="form-control" value="<?php echo Session::get('account_address') ?>">
                                </div>

                                <div class="col-md-12"><label class="labels"><?php echo e(__('profile/UserProfile.Phone Number')); ?></label>
                                    <input name="account_phone" type="text" class="form-control" value="<?php echo Session::get('account_phone') ?>">
                                </div>
                                <?php $__errorArgs = ['account_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div class="mt-5 text-center">
                                <input class="btn btn-outline-success" type="submit" value="<?php echo e(__('profile/UserProfile.Save Profile')); ?>">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="col-lg-9 my-lg-0 my-1">
            <center class="m-5">
                <a type="button" class="nav-icon position-relative text-decoration-none text-dark" href="<?php echo e(URL::to('/login')); ?>">
                    <?php echo e(__('profile/UserProfile.You have to')); ?>

                    <i class="fa fa-fw fa-lock text-dark mr-3"></i>
                    <?php echo e(__('profile/UserProfile.Login')); ?>

                </a>
            </center>
        </div>
        <?php endif; ?>
    </div>

</div>
<!-- End Content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.public_layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/profile/user_profile.blade.php ENDPATH**/ ?>