
<?php $__env->startSection('admin_content'); ?>
    <div class="text-center">
        <h3>
            Welcome to admin page
        </h3>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>