
<?php $__env->startSection('admin_content'); ?>


<div class="container">
    <div class="col-lg-11">
    <?php if(!$edit_sub_category->isEmpty()): ?>
    <?php $__currentLoopData = $edit_sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>
                            Edit subcategory: <?php echo e($edit_value->subcategory_name); ?>

                        </h6>
                    </div>
                    <div class="col-lg-6 col-5 my-auto text-end">
                        <div class="dropdown float-lg-end pe-4">
                            <a class="cursor-pointer" id="dropdownTable" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-ellipsis-v text-secondary"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="col-md-7 container">
                    <form role="form" method="POST" action="<?php echo e(URL::to('/update-sub-category/'.$edit_value->subcategory_id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="input-group input-group-outline my-3">
                            <label class="form-label">
                                SubCategory Name
                            </label>
                            <input value="<?php echo e($edit_value->subcategory_name); ?>" name="subcategory_name" type="text" class="form-control">
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <label class="form-label" for="ckeditorAdd">
                                Category Description
                            </label>
                            <textarea name="subcategory_desc" placeholder="Enter SubCategory Description" class="form-control" id="ckeditorAdd" rows="8">
                                <?php echo e($edit_value->subcategory_desc); ?>

                            </textarea>
                        </div>
                        <div class="input-group input-group-outline mb-3">
                            <!-- <label for="category_id" class="form-label">Choose your category from the list:</label> -->
                            <input class="form-control" list="category" name="category_id" id="category_id" value="<?php echo e($edit_value->category_id); ?>">
                            <datalist id="category">
                            <?php if(!$get_category->isEmpty()): ?>
                                <?php $__currentLoopData = $get_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(($edit_value->category_id == $get_category->category_id) ? 'selected' : ''); ?>

                                          value="<?php echo e($get_category->category_id); ?>">
                                            <?php echo e($get_category->category_name); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <option disabled>No category available</option>
                            <?php endif; ?>
                            </datalist>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">
                                Save subcategory
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <center>
            <h3>
                Somthing went wrong
            </h3>
        </center>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/admin/subcategory/edit_sub_category.blade.php ENDPATH**/ ?>