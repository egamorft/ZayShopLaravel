
<?php $__env->startSection('content'); ?>



<section class="h-100 h-custom" style="background-color: #59AB6E;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12">
                <div class="card card-registration card-registration-2" style="border-radius: 15px;">
                    <div class="card-body p-0">
                        <div class="row g-0">
                            <div class="col-lg-8">
                                <div class="p-5">
                                    <div class="d-flex justify-content-between align-items-center mb-5">
                                        <h1 class="fw-bold mb-0 text-black">
                                            <?php echo e(__('cart/cart.Zay Shopping Cart')); ?>

                                        </h1>
                                        <h6 class="mb-0 text-muted">
                                            <?php echo e(count(Cart::content())); ?> <?php echo e(__('cart/cart.products')); ?>

                                        </h6>
                                    </div>
                                    <?php
                                    $content = Cart::content();
                                    ?>
                                    <?php if(count(Cart::content()) == 0): ?>
                                    <h2>
                                        <?php echo e(__('cart/cart.Your cart is empty!')); ?>

                                    </h2>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <hr class="my-4">
                                    <?php if($value->options->in_stock < $value->qty): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(__('cart/cart.Product in stock is only')); ?> <?php echo e($value->options->in_stock); ?> <?php echo e(__('cart/cart.product left!! Please order less or pick another')); ?>

                                        </div>
                                    <?php endif; ?>
                                        <div class="row mb-4 d-flex justify-content-between align-items-center 
                                        <?php echo e($value->options->in_stock < $value->qty ? 'bg-danger' : ''); ?>">
                                            <div class="col-md-2 col-lg-2 col-xl-2">
                                                <img src="<?php echo e(URL::to('/storage/app/public/products/'.$value->options->image)); ?>" class="img-fluid rounded-3" alt="Cotton T-shirt">
                                            </div>
                                            <div class="col-md-3 col-lg-3 col-xl-3">
                                                <h6 class="text-black mb-0">
                                                    <?php echo e($value->name); ?>

                                                </h6>
                                            </div>
                                            <div class="col-md-3 col-lg-3 col-xl-2">
                                                <form action="<?php echo e(URL::to('/update-cart')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input min="1" name="cart_quantity" value="<?php echo e($value->qty); ?>" type="number" class="form-control form-control-sm" />
                                                    <input type="hidden" value="<?php echo e($value->rowId); ?>" name="rowId_cart">
                                                    <button type="submit" value="<?php echo e(__('cart/cart.Update')); ?>" name="update_qty" class="btn btn-success"><i class="fa-solid fa-circle-check"></i></button>
                                                </form>
                                            </div>
                                            <div class="col-md-3 col-lg-3 col-xl-3 offset-lg-1">
                                                <h6 class="mb-0">
                                                    <?php
                                                    $subtotal = $value->price * $value->qty;
                                                    echo number_format($subtotal, 0, ',', '.') . ' ' . 'đ';
                                                    ?>
                                                </h6>
                                            </div>
                                            <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                                                <a href="<?php echo e(URL::to('/delete-cart/'.$value->rowId)); ?>" class="text-muted"><i class="fas fa-times"></i></a>
                                            </div>
                                        </div>
                                        <hr class="my-4">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-lg-4 bg-grey">
                                <div class="p-5">
                                    <h3 class="fw-bold mb-5 mt-2 pt-1">
                                        <?php echo e(__('cart/cart.Summary')); ?>

                                    </h3>
                                    <hr class="my-4">

                                    <div class="d-flex justify-content-between mb-4">
                                        <h5 class="text-uppercase">
                                            <?php echo e(__('cart/cart.products')); ?> <?php echo e(count(Cart::content())); ?>

                                        </h5>
                                        <h5>
                                            <?php echo e(Cart::pricetotal(0 , ',' , '.').' '.'VNĐ'); ?>

                                        </h5>
                                    </div>
                                    <div class="d-flex justify-content-between mb-4">
                                        <h5 class="text-uppercase">
                                            <?php echo e(__('cart/cart.Taxes')); ?>

                                        </h5>
                                        <h5>
                                            <?php echo e(Cart::tax(0 , ',' , '.').' '.'VNĐ'); ?>

                                        </h5>
                                    </div>
                                    <?php if(Session::get('coupon')): ?>
                                    <?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cou['coupon_condition']==1): ?>
                                    <?php
                                    Cart::setGlobalDiscount($cou['coupon_number']);
                                    ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>


                                    <?php if(Session::get('coupon')): ?>
                                    <?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cou['coupon_condition']==1): ?>
                                    <div class="d-flex justify-content-between mb-4">
                                        <h5 class="text-uppercase">
                                            <?php echo e(__('cart/cart.Discount')); ?>

                                            <span class="text-muted">
                                                <?php
                                                echo '( -' . $cou['coupon_number'] . '%)'
                                                ?>
                                            </span>
                                        </h5>
                                        <h5>
                                            <?php echo e(Cart::discount(0 , ',' , '.').' '.'VNĐ'); ?>

                                        </h5>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <div class="d-flex justify-content-between mb-4">
                                        <h5 class="text-uppercase">
                                            <?php echo e(__('cart/cart.Discount')); ?>

                                        </h5>
                                        <h5>
                                            <?php echo e(Cart::discount(0 , ',' , '.').' '.'VNĐ'); ?>

                                        </h5>
                                    </div>
                                    <?php endif; ?>

                                    <h5 class="text-uppercase mb-3"><?php echo e(__('cart/cart.Give code')); ?></h5>

                                    <form class="card p-2" method="POST" action="<?php echo e(URL::to('/check-coupon')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="input-group">
                                            <?php if(Session::get('coupon') == null): ?>
                                            <input type="text" class="form-control" name="coupon" placeholder="<?php echo e(__('cart/cart.Promo code')); ?>" value="<?php echo e(old('coupon')); ?>">
                                            <button type="submit" class="btn btn-danger check_coupon" name="check_coupon">
                                                <?php echo e(__('cart/cart.Add code')); ?>

                                            </button>
                                            <?php else: ?>
                                            <input disabled type="text" class="form-control" name="coupon" placeholder="<?php echo e(__('cart/cart.Promo code')); ?>" value="<?php echo e(old('coupon')); ?>">
                                            <button disabled type="submit" class="btn btn-dark check_coupon" name="check_coupon">
                                                <?php echo e(__('cart/cart.Add code')); ?>

                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </form>

                                    <hr class="my-4">

                                    <div class="d-flex justify-content-between mb-5">
                                        <h5 class="text-uppercase">
                                            <?php echo e(__('cart/cart.Total price')); ?>

                                        </h5>
                                        <h5>
                                            <?php echo e(Cart::total(0 , ',' , '.').' '.'VNĐ'); ?>

                                        </h5>
                                    </div>
                                    <?php if(Session::get('account_id') != null): ?>
                                    <a href="<?php echo e(URL::to('/check-out')); ?>" type="button" class="btn btn-dark btn-block btn-lg" data-mdb-ripple-color="dark">
                                        <?php echo e(__('cart/cart.Checkout')); ?>

                                    </a>
                                    <?php else: ?>
                                    <a href="<?php echo e(URL::to('/login')); ?>" type="button" class="btn btn-dark btn-block btn-lg" data-mdb-ripple-color="dark">
                                        <?php echo e(__('cart/cart.Checkout')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if(Session::get('coupon') != null): ?>
                                    <a style="margin-left: 50px;" href="<?php echo e(URL::to('/unset-coupon')); ?>" type="button" class="btn btn-dark btn-block btn-lg" data-mdb-ripple-color="dark">
                                        <?php echo e(__('cart/cart.Unset coupon')); ?>

                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <h6 class="mb-0">
                                <a href="<?php echo e(URL::to('/shop')); ?>" class="btn btn-outline-success">
                                    <i class="fas fa-long-arrow-alt-left me-2"></i>
                                    <?php echo e(__('cart/cart.Shopping more')); ?>

                                </a>
                            </h6>
                            <hr class="my-4">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.public_layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/pages/cart/shop_cart.blade.php ENDPATH**/ ?>