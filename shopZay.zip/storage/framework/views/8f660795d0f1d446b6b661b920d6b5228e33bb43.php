<?php $__env->startSection('alert_content'); ?>
<!-- Alert -->
<?php if(session()->has('message')): ?>
<div class="container">
    <div class="row">
        <div class="col-9"></div>
        <div class="col-sm-3">
            <div id="alertMessage" class="alert alert-success">
                <strong>Success! </strong>
                <?php echo e(session()->get('message')); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php
Session::forget('message');
?>
<?php elseif(session()->has('error')): ?>
<div class="container">
    <div class="row">
        <div class="col-9"></div>
        <div class="col-sm-3">
            <div id="alertMessage" class="alert alert-danger">
                <strong>Error! </strong>
                <?php echo e(session()->get('error')); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php
Session::forget('error');
?>
<?php endif; ?>
<!-- End Alert -->
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\shopZay\resources\views/components/alert/alert.blade.php ENDPATH**/ ?>