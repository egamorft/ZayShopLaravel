<?php 
return [
    'Reset your password' => 'Reset your password',
    'Zay Shop' => 'Zay Shop',
    'Enter your email' => 'Enter your email',
    'Reset password' => 'Reset password',
];