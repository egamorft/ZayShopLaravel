<?php 
return [
    'Account' => 'Account',
    'My Profile' => 'My Profile',
    'Change your profile' => 'Change your profile',
    'Password' => 'Password',
    'Change your password' => 'Change your password',
    'My Order' => 'My Order',
    'View & Manage your orders' => 'View & Manage your orders',
    'Password Settings' => 'Password Settings',
    'Old Password' => 'Old Password',
    'New Password' => 'New Password',
    'Confirm Password' => 'Confirm Password',
    'Save Profile' => 'Save Profile',
    'You have to' => 'You have to',
    'Login' => 'Login',
];