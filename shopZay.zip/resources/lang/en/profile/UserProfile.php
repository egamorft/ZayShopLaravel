<?php 
return [
    'Account' => 'Account',
    'My Profile' => 'My Profile',
    'Change your profile' => 'Change your profile',
    'Password' => 'Password',
    'Change your password' => 'Change your password',
    'My Order' => 'My Order',
    'View & Manage your orders' => 'View & Manage your orders',
    'Profile Settings' => 'Profile Settings',
    'Full Name' => 'Full Name',
    'Email' => 'Email',
    'Address' => 'Address',
    'Phone Number' => 'Phone Number',
    'Save Profile' => 'Save Profile',
    'You have to' => 'You have to',
    'Login' => 'Login',
];