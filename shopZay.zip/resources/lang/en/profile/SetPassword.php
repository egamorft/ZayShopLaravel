<?php 
return [
    'Set your new password' => 'Set your new password',
    'Zay Shop' => 'Zay Shop',
    'New Password' => 'New Password',
    'Confirm Password' => 'Confirm Password',
    'Set password' => 'Set password',
    'Enter password' => 'Enter password',
    'Enter confirm password' => 'Enter confirm password',
];