<?php
return [
    'Zay Shopping Cart' => 'Zay Shopping Cart',
    'Your cart is empty!' => 'Your cart is empty!',
    'products' => 'products',
    'Product in stock is only' => 'Product in stock is only',
    'product left!! Please order less or pick another' => 'product left!! Please order less or pick another',
    'Update' => 'Update',
    'Summary' => 'Summary',
    'Taxes' => 'Taxes',
    'Discount' => 'Discount',
    'Give code' => 'Give code',
    'Promo code' => 'Promo code',
    'Add code' => 'Add code',
    'Total price' => 'Total price',
    'Checkout' => 'Checkout',
    'Unset coupon' => 'Unset coupon',
    'Shopping more' => 'Shopping more',
];