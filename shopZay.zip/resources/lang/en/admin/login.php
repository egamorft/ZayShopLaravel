<?php
return [
    'ShopZay' => 'Shop Zay',
    'Admin' => 'Admin',
    'Sign in' => 'Sign in',
    'Email' => 'Email',
    'Password' => 'Password',
    'Remember me' => 'Remember me',
    'Log in' => 'Log in',
];