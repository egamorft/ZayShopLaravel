<?php
return [
    'Current Online' => 'Current Online',
    'than yesterday' => 'than yesterday',
    'This month visitors' => 'This month visitors',
    'than last month' => 'than last month',
    'This Year Visitors' => 'This Year Visitors',
    'than last year' => 'than last year',
    'Total Pages Visitors' => 'Total Pages Visitors',
    'Sales statistic' => 'Sales statistic',
    'From date:' => 'From date:',
    'End date:' => 'End date:',
    'Dashboard Filter' => 'Dashboard Filter',
    'Choose type filter' => 'Choose type filter',
    '7 last days' => '7 last days',
    'Last month' => 'Last month',
    'This month' => 'This month',
    'Last 365 days' => 'Last 365 days',
    'Pages Statistic' => 'Pages Statistic',
    'Filter' => 'Filter'
];