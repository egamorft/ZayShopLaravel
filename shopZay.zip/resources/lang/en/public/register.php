<?php
return [
    'Register to' => 'Register to',
    'Zay Shop' => 'Zay Shop',
    'Full name' => 'Full name',
    'Email' => 'Email',
    'Phone' => 'Phone',
    'Password' => 'Password',
    'Confirm Password' => 'Confirm Password',
    'Sign In' => 'Sign In',
    'Already have account?' => 'Already have account?',
    'Log in now' => 'Log in now',
];