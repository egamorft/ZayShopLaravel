<?php
return [
    'Sign In to' => 'Sign In to',
    'Zay Shop' => 'Zay Shop',
    'Email' => 'Email',
    'Password' => 'Password',
    'Log In' => 'Log In',
    'You forgot your password?' => 'You forgot your password?',
    'Reset now' => 'Reset now',
    "Don't have account? Register" => "Don't have account? Register",
    'Here' => 'Here',
    'or sign in with' => 'or sign in with',
];