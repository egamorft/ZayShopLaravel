<?php 
return [
    'About Us' => 'About Us',
    'This website is created to sell as well as demo a project coding in laravel.' => 'This website is created to sell as well as demo a project coding in laravel.',
    'Our Services' => 'Our Services',
    "It's important to have a good customer, it's going to be successful, but that's how it's important to have a good customer." => "It's important to have a good customer, it's going to be successful, but that's how it's important to have a good customer.",
    'Delivery Services' => 'Delivery Services',
    'Shipping & Return' => 'Shipping & Return',
    'Promotion' => 'Promotion',
    '24 Hours Service' => '24 Hours Service',
];