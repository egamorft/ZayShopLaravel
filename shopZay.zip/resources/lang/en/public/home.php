<?php
return [
    'Categories of The Month' => 'Categories of The Month',
    'Here are the notable categories this month' => 'Here are the notable categories this month',
    'Watches' => 'Watches',
    'Go Shop' => 'Go Shop',
    'Shoes' => 'Shoes',
    'Accessories' => 'Accessories',
];