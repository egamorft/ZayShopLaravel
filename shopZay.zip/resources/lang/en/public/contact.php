<?php
return [
    'Contact Us' => 'Contact Us',
    'We were here and will give you the best experience.' => 'We were here and will give you the best experience.',
    'Name' => 'Name',
    'Email' => 'Email',
    'Subject' => 'Subject',
    'Message' => 'Message',
    "Let’s Talk" => "Let’s Talk",
];