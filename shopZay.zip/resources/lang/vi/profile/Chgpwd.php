<?php 
return [
    'Account' => 'Quản lý tài khoản',
    'My Profile' => 'Hồ sơ của tôi',
    'Change your profile' => 'Thay đổi thông tin tài khoản',
    'Password' => 'Mật khẩu',
    'Change your password' => 'Thay đổi mật khẩu',
    'My Order' => 'Đơn hàng',
    'View & Manage your orders' => 'Xem & quản lý đơn hàng',
    'Password Settings' => 'Chỉnh sửa mật khẩu',
    'Old Password' => 'Mật khẩu cũ',
    'New Password' => 'Mật khẩu mới',
    'Confirm Password' => 'Xác nhận mật khẩu',
    'Save Profile' => 'Lưu mật khẩu',
    'You have to' => 'Bạn cần phải',
    'Login' => 'Đăng nhập',
];