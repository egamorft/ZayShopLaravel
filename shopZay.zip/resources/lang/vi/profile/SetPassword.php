<?php 
return [
    'Set your new password' => 'Thiết lập mật khẩu mới',
    'Zay Shop' => 'cửa hàng ZAY',
    'New Password' => 'Mật khẩu mới',
    'Confirm Password' => 'Xác nhận mật khẩu mới',
    'Set password' => 'Thiết lập mật khẩu',
    'Enter password' => 'Nhập mật khẩu',
    'Enter confirm password' => 'Nhập lại mật khẩu',
];