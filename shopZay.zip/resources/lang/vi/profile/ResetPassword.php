<?php 
return [
    'Reset your password' => 'Lấy lại mật khẩu',
    'Zay Shop' => 'cửa hàng ZAY',
    'Enter your email' => 'Nhập e-mail của bạn',
    'Reset password' => 'Lấy lại mật khẩu',
];