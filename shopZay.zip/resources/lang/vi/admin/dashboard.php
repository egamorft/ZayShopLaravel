<?php
return [
    'Current Online' => 'Đang hoạt động',
    'than yesterday' => 'hơn hôm qua',
    'This month visitors' => 'Lượt truy cập tháng này',
    'than last month' => 'Lượt truy cập tháng trước',
    'This Year Visitors' => 'Lượt truy cập năm nay',
    'than last year' => 'hơn năm ngoái',
    'Total Pages Visitors' => 'Tổng lượt truy cập trang',
    'Sales statistic' => 'Thống kê doanh số',
    'From date:' => 'Từ ngày:',
    'End date:' => 'Đến ngày:',
    'Dashboard Filter' => 'Lọc bảng điều khiển',
    'Choose type filter' => 'Chọn loại để lọc',
    '7 last days' => '7 ngày trước',
    'Last month' => 'Tháng trước',
    'This month' => 'Tháng này',
    'Last 365 days' => '365 ngày trở về',
    'Pages Statistic' => 'Thống kê trang',
    'Filter' => 'Lọc'
];