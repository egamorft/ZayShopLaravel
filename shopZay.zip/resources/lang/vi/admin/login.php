<?php
return [
    'ShopZay' => 'Cửa hàng Zay',
    'Admin' => 'Quản trị viên',
    'Sign in' => 'Đăng nhập',
    'Email' => 'E-mail',
    'Password' => 'Mật khẩu',
    'Remember me' => 'Ghi nhớ đăng nhập',
    'Log in' => 'Đăng nhập',
];