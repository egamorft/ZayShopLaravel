<?php
return [
    'Sign In to' => 'Đăng nhập vào',
    'Zay Shop' => 'cửa hàng ZAY',
    'Email' => 'E-mail',
    'Password' => 'Mật khẩu',
    'Log In' => 'Đăng nhập',
    'You forgot your password?' => 'Bạn quên mật khẩu ư?',
    'Reset now' => 'Lấy lại ngay',
    "Don't have account? Register" => "Bạn không có tài khoản? Đăng kí",
    'Here' => 'Tại đây',
    'or sign in with' => 'hoặc đăng nhập với',
];