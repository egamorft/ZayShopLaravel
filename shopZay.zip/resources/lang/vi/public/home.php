<?php
return [
    'Categories of The Month' => 'Danh mục của tháng',
    'Here are the notable categories this month' => 'Dưới đây là các danh mục đáng chú ý trong tháng này',
    'Watches' => 'Đồng hồ',
    'Go Shop' => 'Tìm hiểu ngay',
    'Shoes' => 'Giày',
    'Accessories' => 'Phụ kiện',
];