<?php
return [
    'Register to' => 'Đăng ký tài khoản',
    'Zay Shop' => 'cửa hàng ZAY',
    'Full name' => 'Họ và tên',
    'Email' => 'E-mail',
    'Phone' => 'Số điện thoại',
    'Password' => 'Mật khẩu',
    'Confirm Password' => 'Nhập lại mật khẩu',
    'Sign In' => 'Đăng ký',
    'Already have account?' => 'Bạn đã có tài khoản?',
    'Log in now' => 'Đăng nhập ngay',
];