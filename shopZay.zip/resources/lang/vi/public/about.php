<?php 
return [
    'About Us' => 'Về chúng tôi',
    'This website is created to sell as well as demo a project coding in laravel.' => 'Trang web này được tạo ra nhằm bán hàng cũng như demo 1 project viết code bằng laravel ',
    'Our Services' => 'Dịch vụ',
    "It's important to have a good customer, it's going to be successful, but that's how it's important to have a good customer." => "Điều quan trọng là có được khách hàng tốt thì sẽ thành công, nhưng đó là cách quan trọng để có được một khách hàng tốt.",
    'Delivery Services' => 'Dịch vụ vận chuyển',
    'Shipping & Return' => 'Giao hàng & Hoàn trả',
    'Promotion' => 'Ưu đãi',
    '24 Hours Service' => 'Phục vụ 24/7',
];