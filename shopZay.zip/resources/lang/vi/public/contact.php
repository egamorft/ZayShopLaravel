<?php
return [
    'Contact Us' => 'Liên hệ với chúng tôi',
    'We were here and will give you the best experience.' => 'Chúng tôi đã ở đây và sẽ mang đến cho bạn trải nghiệm tốt nhất.',
    'Name' => 'Tên',
    'Email' => 'E-mail',
    'Subject' => 'Chủ đề',
    'Message' => 'Tin nhắn',
    "Let’s Talk" => "Hãy nói chuyện nào",
];