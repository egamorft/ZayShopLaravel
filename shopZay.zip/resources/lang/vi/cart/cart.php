<?php
return [
    'Zay Shopping Cart' => 'Giỏ hàng ZAY',
    'Your cart is empty!' => 'Giỏ hàng của bạn đang trống!',
    'products' => 'sản phẩm',
    'Product in stock is only' => 'Sản phẩm trong kho chỉ còn',
    'product left!! Please order less or pick another' => 'sản phẩm nữa!! Hãy giảm bớt hoặc chọn sản phẩm khác nhé',
    'Update' => 'Cập nhật',
    'Summary' => 'Tổng hợp',
    'Taxes' => 'Thuế',
    'Discount' => 'Giảm giá',
    'Give code' => 'Bạn có mã giảm giá?',
    'Promo code' => 'Mã giảm giá',
    'Add code' => 'Thêm mã',
    'Total price' => 'Thành tiền',
    'Checkout' => 'Thanh toán',
    'Unset coupon' => 'Hủy mã',
    'Shopping more' => 'Mua sắm thêm',
];