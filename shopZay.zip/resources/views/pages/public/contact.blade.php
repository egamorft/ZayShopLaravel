@extends('components.public_layout.layout')
@section('content')

<!-- Start Content Page -->
<div class="container-fluid bg-light py-5">
    <div class="col-md-6 m-auto text-center">
        <h1 class="h1">{{ __('public/contact.Contact Us')}}</h1>
        <p>
            {{ __('public/contact.We were here and will give you the best experience.')}}
        </p>
    </div>
</div>

<!-- Start Map -->
<div id="mapid" style="width: 100%; height: 300px;"></div>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" 
integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<script>
    var mymap = L.map('mapid').setView([21.030377285331205, 105.78594674644998, 13], 13);

    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        maxZoom: 18,
        attribution: 
        'Zay Telmplte | Template Design by <a href="https://templatemo.com/">Templatemo</a> | Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
            '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
            'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1
    }).addTo(mymap);

    L.marker([21.030377285331205, 105.78594674644998, 13]).addTo(mymap)
        .bindPopup("<b>Co-well</b> Company<br />Location.").openPopup();

    mymap.scrollWheelZoom.disable();
    mymap.touchZoom.disable();
</script>
<!-- Ena Map -->

<!-- Start Contact -->
<div class="container py-5">
    <div class="row py-5">
        <form class="col-md-9 m-auto" method="post" role="form">
            <fieldset disabled="disabled">
                <div class="row">
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputname">{{ __('public/contact.Name')}}</label>
                        <input type="text" class="form-control mt-1" id="name" name="name" placeholder="{{ __('public/contact.Name')}}">
                    </div>
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputemail">{{ __('public/contact.Email')}}</label>
                        <input type="email" class="form-control mt-1" id="email" name="email" placeholder="{{ __('public/contact.Email')}}">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="inputsubject">{{ __('public/contact.Subject')}}</label>
                    <input type="text" class="form-control mt-1" id="subject" name="subject" placeholder="{{ __('public/contact.Subject')}}">
                </div>
                <div class="mb-3">
                    <label for="inputmessage">{{ __('public/contact.Message')}}</label>
                    <textarea class="form-control mt-1" id="message" name="message" placeholder="{{ __('public/contact.Message')}}" rows="8"></textarea>
                </div>
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit" class="btn btn-success btn-lg px-3">{{ __('public/contact.Let’s Talk')}}</button>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<!-- End Contact -->

@endsection