@extends('components.admin_layout.admin_layout')
@section('admin_content')
<div id="vue">
    <coupon></coupon>
</div>
@endsection