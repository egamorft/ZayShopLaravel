@extends('components.admin_layout.admin_layout')
@section('admin_content')
<div id="vue">
    <subcategory></subcategory>
</div>

@endsection