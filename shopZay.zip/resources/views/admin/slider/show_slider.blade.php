@extends('components.admin_layout.admin_layout')
@section('admin_content')
<div id="vue">
    <slider></slider>
</div>
@endsection